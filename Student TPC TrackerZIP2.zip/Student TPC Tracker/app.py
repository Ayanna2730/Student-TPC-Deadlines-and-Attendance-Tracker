from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import mysql.connector
import hashlib
from datetime import datetime, date, timedelta
import os
from dotenv import load_dotenv
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Load environment variables
load_dotenv()

app = Flask(__name__, 
    static_folder='static',
    template_folder='templates')
app.secret_key = os.getenv('SECRET_KEY') or 'your-secret-key-here'

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Database configuration
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host=os.getenv('MYSQL_HOST', 'localhost'),
            user=os.getenv('MYSQL_USER', 'root'),
            password=os.getenv('MYSQL_PASSWORD', 'hp-2024aleah'),
            database=os.getenv('MYSQL_DB', 'tracksmart')
        )
        return conn
    except mysql.connector.Error as e:
        print(f"Database connection error: {e}")
        return None

# Initialize database with proper schema
def init_db():
    try:
        conn = get_db_connection()
        if not conn:
            # Try to connect without database first to create it
            conn = mysql.connector.connect(
                host='localhost',
                user='root',
                password='hp-2024aleah'
            )
        
        cursor = conn.cursor()
        
        # Create database if not exists
        cursor.execute("CREATE DATABASE IF NOT EXISTS tracksmart")
        cursor.execute("USE tracksmart")
        
        # Create users table with proper schema
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create password_reset_tokens table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                token VARCHAR(255) NOT NULL UNIQUE,
                expires_at TIMESTAMP NOT NULL,
                used BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        
        # Create tasks table with proper schema (NO PRIORITY)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                deadline DATE,
                status ENUM('pending', 'completed') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS semesters (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                name VARCHAR(255) NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)
        
        # Create classes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS classes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                semester_id INT NOT NULL,
                course_code VARCHAR(50) NOT NULL,
                course_name VARCHAR(255) NOT NULL,
                instructor VARCHAR(255),
                credits INT DEFAULT 3,
                color VARCHAR(7) DEFAULT '#3b82f6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE
            )
        """)
        
        # Create class_schedules table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS class_schedules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                class_id INT NOT NULL,
                day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                room VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
            )
        """)
        
        # Create attendance_records table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS attendance_records (
                id INT AUTO_INCREMENT PRIMARY KEY,
                class_id INT NOT NULL,
                date DATE NOT NULL,
                status ENUM('present', 'absent', 'late', 'excused') NOT NULL,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
            )
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
        print("Database initialized successfully")
        return True
        
    except mysql.connector.Error as e:
        print(f"Error initializing database: {e}")
        return False

# Initialize database when app starts
init_db()

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Please enter both email and password', 'error')
            return redirect(url_for('login'))
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Check user credentials
            hashed_password = hash_password(password)
            cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", 
                         (email, hashed_password))
            user = cursor.fetchone()
            
            cursor.close()
            conn.close()
            
            if user:
                session['user'] = {
                    'id': user['id'],
                    'username': user['username'],
                    'email': user['email']
                }
                flash('Login successful!', 'success')
                return redirect(url_for('home'))
            else:
                flash('Invalid email or password', 'error')
                return redirect(url_for('login'))
                
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
            print(f"Database error: {e}")
            return redirect(url_for('login'))
    
    return render_template('login1.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Basic validation
        if not username or not email or not password:
            flash('All fields are required', 'error')
            return redirect(url_for('login', show='register'))
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return redirect(url_for('login', show='register'))
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Check if user already exists
            cursor.execute("SELECT id FROM users WHERE email = %s OR username = %s", (email, username))
            existing_user = cursor.fetchone()
            
            if existing_user:
                flash('User already exists with this email or username', 'error')
                cursor.close()
                conn.close()
                return redirect(url_for('login', show='register'))
            
            # Insert new user
            cursor.execute(
                "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                (username, email, hash_password(password))
            )
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # Get the new user data for session
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            # Set session
            session['user'] = {
                'id': user['id'],
                'username': user['username'],
                'email': user['email']
            }
            
            flash('Registration successful! Welcome to TrackSmart!', 'success')
            return redirect(url_for('home'))
            
        except mysql.connector.Error as e:
            flash('Registration failed. Please try again.', 'error')
            print(f"Database error: {e}")
            return redirect(url_for('login', show='register'))
    
    # If GET request, show the registration form
    return redirect(url_for('login', show='register'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/')
@app.route('/home')
def home():
    if 'user' not in session:
        upcoming_tasks = []
    else:
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT * FROM tasks 
                WHERE user_id = %s AND deadline >= CURDATE() AND status != 'completed'
                ORDER BY deadline ASC LIMIT 5
            """, (session['user']['id'],))
            upcoming_tasks = cursor.fetchall()
            cursor.close()
            conn.close()
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            upcoming_tasks = []
            
    return render_template('homepage.html', upcoming_tasks=upcoming_tasks)

# Password Reset Routes
@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    email = request.form.get('email')
    
    if not email:
        flash('Please enter your email address', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Check if user exists
        cursor.execute("SELECT id, username FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        
        if not user:
            # Don't reveal whether email exists for security
            flash('If an account with that email exists, a password reset link has been sent.', 'info')
            cursor.close()
            conn.close()
            return redirect(url_for('login'))
        
        # Generate reset token
        token = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(hours=1)
        
        # Store token in database
        cursor.execute(
            "INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (%s, %s, %s)",
            (user['id'], token, expires_at)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        # In a real application, send email here
        # For now, we'll just show the reset link
        reset_url = url_for('reset_password', token=token, _external=True)
        print(f"Password reset URL for {email}: {reset_url}")
        
        flash('If an account with that email exists, a password reset link has been sent.', 'info')
        return redirect(url_for('login'))
        
    except mysql.connector.Error as e:
        flash('An error occurred. Please try again.', 'error')
        print(f"Database error: {e}")
        return redirect(url_for('login'))

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if request.method == 'GET':
        # Verify token is valid
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            cursor.execute("""
                SELECT u.id, u.username 
                FROM password_reset_tokens prt 
                JOIN users u ON prt.user_id = u.id 
                WHERE prt.token = %s AND prt.expires_at > NOW() AND prt.used = FALSE
            """, (token,))
            
            token_data = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if not token_data:
                flash('Invalid or expired reset token.', 'error')
                return redirect(url_for('login'))
            
            return render_template('reset_password.html', token=token, username=token_data['username'])
            
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
            print(f"Database error: {e}")
            return redirect(url_for('login'))
    
    else:  # POST request
        new_password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not new_password or not confirm_password:
            flash('Please fill in all fields', 'error')
            return render_template('reset_password.html', token=token)
        
        if new_password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('reset_password.html', token=token)
        
        if len(new_password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return render_template('reset_password.html', token=token)
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Verify token is still valid
            cursor.execute("""
                SELECT user_id FROM password_reset_tokens 
                WHERE token = %s AND expires_at > NOW() AND used = FALSE
            """, (token,))
            
            token_data = cursor.fetchone()
            
            if not token_data:
                flash('Invalid or expired reset token.', 'error')
                cursor.close()
                conn.close()
                return redirect(url_for('login'))
            
            # Update user password
            cursor.execute(
                "UPDATE users SET password = %s WHERE id = %s",
                (hash_password(new_password), token_data['user_id'])
            )
            
            # Mark token as used
            cursor.execute(
                "UPDATE password_reset_tokens SET used = TRUE WHERE token = %s",
                (token,)
            )
            
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Your password has been reset successfully! Please log in with your new password.', 'success')
            return redirect(url_for('login'))
            
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
            print(f"Database error: {e}")
            return render_template('reset_password.html', token=token)

# Tasks Routes
@app.route('/tasks')
def tasks():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('task.html')

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'Database connection failed'}), 500
            
        cursor = conn.cursor(dictionary=True)
        
        # Get all tasks for user
        cursor.execute("SELECT * FROM tasks WHERE user_id = %s ORDER BY deadline ASC", (user_id,))
        tasks = cursor.fetchall()
        
        # Convert date objects to strings
        for task in tasks:
            if task['deadline']:
                task['deadline'] = task['deadline'].isoformat()
            task['created_at'] = task['created_at'].isoformat() if task['created_at'] else None
            # Ensure all fields have proper values
            task['description'] = task['description'] or ''
            task['status'] = task.get('status', 'pending')
        
        cursor.close()
        conn.close()
        
        return jsonify(tasks)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks', methods=['POST'])
def create_task():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    title = data.get('title')
    description = data.get('description', '')
    deadline = data.get('deadline')
    user_id = session['user']['id']
    
    if not title:
        return jsonify({'error': 'Title is required'}), 400
    
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'Database connection failed'}), 500
            
        cursor = conn.cursor()
        
        print(f"Creating task: {title}, {description}, {deadline} for user {user_id}")
        
        # Insert task
        cursor.execute(
            "INSERT INTO tasks (user_id, title, description, deadline) VALUES (%s, %s, %s, %s)",
            (user_id, title, description, deadline)
        )
        
        conn.commit()
        task_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        
        print(f"Task created successfully with ID: {task_id}")
        return jsonify({'success': True, 'task_id': task_id})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'Database connection failed'}), 500
            
        cursor = conn.cursor()
        
        # Check if task belongs to user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, user_id))
        task = cursor.fetchone()
        
        if not task:
            cursor.close()
            conn.close()
            return jsonify({'error': 'Task not found'}), 404
        
        # Update task
        cursor.execute(
            "UPDATE tasks SET title = %s, description = %s, deadline = %s WHERE id = %s",
            (data.get('title'), data.get('description'), data.get('deadline'), task_id)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>/status', methods=['PUT'])
def update_task_status(task_id):
    """Endpoint specifically for updating task status"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    user_id = session['user']['id']
    status = data.get('status')
    
    if status not in ['pending', 'completed']:
        return jsonify({'error': 'Invalid status'}), 400
    
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'Database connection failed'}), 500
            
        cursor = conn.cursor()
        
        # Check if task belongs to user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, user_id))
        task = cursor.fetchone()
        
        if not task:
            cursor.close()
            conn.close()
            return jsonify({'error': 'Task not found'}), 404
        
        # Update only the status
        cursor.execute(
            "UPDATE tasks SET status = %s WHERE id = %s",
            (status, task_id)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        if not conn:
            return jsonify({'error': 'Database connection failed'}), 500
            
        cursor = conn.cursor()
        
        # Check if task belongs to user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, user_id))
        task = cursor.fetchone()
        
        if not task:
            cursor.close()
            conn.close()
            return jsonify({'error': 'Task not found'}), 404
        
        # Delete task
        cursor.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Attendance Routes
@app.route('/attendance')
def attendance():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('attendance.html')

# Attendance API Routes
@app.route('/api/semesters', methods=['GET'])
def get_semesters():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT * FROM semesters 
            WHERE user_id = %s 
            ORDER BY start_date DESC
        """, (user_id,))
        semesters = cursor.fetchall()
        
        # Convert date objects to strings
        for semester in semesters:
            semester['start_date'] = semester['start_date'].isoformat()
            semester['end_date'] = semester['end_date'].isoformat()
        
        cursor.close()
        conn.close()
        
        return jsonify(semesters)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/semesters', methods=['POST'])
def create_semester():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    name = data.get('name')
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    user_id = session['user']['id']
    
    if not name or not start_date or not end_date:
        return jsonify({'error': 'Name, start date, and end date are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO semesters (user_id, name, start_date, end_date) VALUES (%s, %s, %s, %s)",
            (user_id, name, start_date, end_date)
        )
        
        conn.commit()
        semester_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'semester_id': semester_id})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes', methods=['POST'])
def create_class():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    semester_id = data.get('semester_id')
    course_code = data.get('course_code')
    course_name = data.get('course_name')
    instructor = data.get('instructor', '')
    credits = data.get('credits', 3)
    color = data.get('color', '#3b82f6')
    schedules = data.get('schedules', [])
    
    if not semester_id or not course_code or not course_name:
        return jsonify({'error': 'Semester, course code, and course name are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Insert class
        cursor.execute(
            "INSERT INTO classes (semester_id, course_code, course_name, instructor, credits, color) VALUES (%s, %s, %s, %s, %s, %s)",
            (semester_id, course_code, course_name, instructor, credits, color)
        )
        
        class_id = cursor.lastrowid
        
        # Insert schedules
        for schedule in schedules:
            cursor.execute(
                "INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)",
                (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', ''))
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'class_id': class_id})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/semesters/<int:semester_id>/classes', methods=['GET'])
def get_classes(semester_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get classes for semester
        cursor.execute("""
            SELECT c.*, s.name as semester_name 
            FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.semester_id = %s AND s.user_id = %s
        """, (semester_id, session['user']['id']))
        classes = cursor.fetchall()
        
        # Get schedules for each class
        for class_obj in classes:
            cursor.execute("""
                SELECT * FROM class_schedules 
                WHERE class_id = %s 
                ORDER BY 
                    FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
                    start_time
            """, (class_obj['id'],))
            schedules = cursor.fetchall()
            
            # Convert time objects to strings
            for schedule in schedules:
                schedule['start_time'] = str(schedule['start_time'])
                schedule['end_time'] = str(schedule['end_time'])
            
            class_obj['schedules'] = schedules
            
            # Get attendance stats
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_sessions,
                    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_count,
                    SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
                    SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_count,
                    SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) as excused_count
                FROM attendance_records 
                WHERE class_id = %s
            """, (class_obj['id'],))
            stats = cursor.fetchone()
            
            # Ensure all counts are integers (not None)
            if stats:
                class_obj['attendance_stats'] = {
                    'total_sessions': stats['total_sessions'] or 0,
                    'present_count': stats['present_count'] or 0,
                    'absent_count': stats['absent_count'] or 0,
                    'late_count': stats['late_count'] or 0,
                    'excused_count': stats['excused_count'] or 0
                }
            else:
                class_obj['attendance_stats'] = {
                    'total_sessions': 0,
                    'present_count': 0,
                    'absent_count': 0,
                    'late_count': 0,
                    'excused_count': 0
                }
        
        cursor.close()
        conn.close()
        
        return jsonify(classes)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/classes/<int:class_id>', methods=['PUT'])
def update_class(class_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    course_code = data.get('course_code')
    course_name = data.get('course_name')
    instructor = data.get('instructor', '')
    credits = data.get('credits', 3)
    color = data.get('color', '#3b82f6')
    schedules = data.get('schedules', [])
    
    if not course_code or not course_name:
        return jsonify({'error': 'Course code and course name are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Update class
        cursor.execute("""
            UPDATE classes 
            SET course_code = %s, course_name = %s, instructor = %s, credits = %s, color = %s
            WHERE id = %s
        """, (course_code, course_name, instructor, credits, color, class_id))
        
        # Delete existing schedules
        cursor.execute("DELETE FROM class_schedules WHERE class_id = %s", (class_id,))
        
        # Insert new schedules
        for schedule in schedules:
            cursor.execute(
                "INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)",
                (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', ''))
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes/<int:class_id>', methods=['DELETE'])
def delete_class(class_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Delete class (cascade will delete schedules and attendance records)
        cursor.execute("DELETE FROM classes WHERE id = %s", (class_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/attendance', methods=['POST'])
def record_attendance():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    class_id = data.get('class_id')
    date = data.get('date')
    status = data.get('status')
    notes = data.get('notes', '')
    
    if not class_id or not date or not status:
        return jsonify({'error': 'Class ID, date, and status are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if attendance already exists for this class and date
        cursor.execute(
            "SELECT id FROM attendance_records WHERE class_id = %s AND date = %s",
            (class_id, date)
        )
        existing_record = cursor.fetchone()
        
        if existing_record:
            # Update existing record
            cursor.execute(
                "UPDATE attendance_records SET status = %s, notes = %s WHERE id = %s",
                (status, notes, existing_record[0])
            )
        else:
            # Insert new record
            cursor.execute(
                "INSERT INTO attendance_records (class_id, date, status, notes) VALUES (%s, %s, %s, %s)",
                (class_id, date, status, notes)
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes/<int:class_id>/attendance', methods=['GET'])
def get_class_attendance(class_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Get attendance records
        cursor.execute("""
            SELECT * FROM attendance_records 
            WHERE class_id = %s 
            ORDER BY date DESC
        """, (class_id,))
        
        attendance_records = cursor.fetchall()
        
        # Convert date objects to strings
        for record in attendance_records:
            record['date'] = record['date'].isoformat()
        
        cursor.close()
        conn.close()
        
        return jsonify(attendance_records)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

if __name__ == '__main__':
    app.run(debug=True)