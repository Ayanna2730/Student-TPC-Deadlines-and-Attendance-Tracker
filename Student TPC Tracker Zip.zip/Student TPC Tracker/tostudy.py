# Import the Flask class to create a web application
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
# Import MySQL connector for database operations
import mysql.connector
# Import hashing library for password security
import hashlib
# Import datetime modules for date/time handling
from datetime import datetime, date, timedelta
# Import operating system interface for environment variables
import os
# Import module to load environment variables from .env file
from dotenv import load_dotenv
# Import secure random number generator for tokens
import secrets

# Load environment variables from .env file into os.environ
load_dotenv()

# Create Flask application instance with custom folders
app = Flask(__name__, static_folder='static', template_folder='templates')
# Set secret key for session encryption from environment variable or use default
app.secret_key = os.getenv('SECRET_KEY') or 'your-secret-key-here'

# Define function to hash passwords
def hash_password(password):
    """Hash password using SHA-256 for secure storage"""
    # Convert password to bytes, hash with SHA-256, return hexadecimal string
    return hashlib.sha256(password.encode()).hexdigest()

# Define function to create database connection
def get_db_connection():
    """Create and return database connection using environment variables"""
    # Try to establish database connection
    try:
        # Create MySQL connection with parameters from environment variables
        conn = mysql.connector.connect(
            # Database host from environment or default to localhost
            host=os.getenv('MYSQL_HOST', 'localhost'),
            # Database user from environment or default to root
            user=os.getenv('MYSQL_USER', 'root'),
            # Database password from environment or use hardcoded (not recommended for production)
            password=os.getenv('MYSQL_PASSWORD', 'hp-2024aleah'),
            # Database name from environment or default to tracksmart
            database=os.getenv('MYSQL_DB', 'tracksmart'),
            # Automatically commit transactions
            autocommit=True
        )
        # Return the connection object if successful
        return conn
    # Handle database connection errors
    except mysql.connector.Error as e:
        # Print error message to console
        print(f"Database connection error: {e}")
        # Return None if connection fails
        return None

# Define function to initialize database tables
def init_db():
    """Initialize database with all required tables"""
    # Try to initialize database
    try:
        # Get database connection
        conn = get_db_connection()
        # Check if connection failed
        if not conn:
            # Try to connect without specifying database (to create it)
            conn = mysql.connector.connect(host='localhost', user='root', password='hp-2024aleah')
        
        # Create cursor to execute SQL commands
        cursor = conn.cursor()
        # Execute SQL to create database if it doesn't exist
        cursor.execute("CREATE DATABASE IF NOT EXISTS tracksmart")
        # Switch to the tracksmart database
        cursor.execute("USE tracksmart")
        
        # List of SQL statements to create all required tables
        tables = [
            # Users table for storing user account information
            """CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
            # Password reset tokens table for secure password recovery (unused)
            """CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                token VARCHAR(255) NOT NULL UNIQUE, expires_at TIMESTAMP NOT NULL,
                used BOOLEAN DEFAULT FALSE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)""",
            # Tasks table for user to-do items
            """CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL, description TEXT, deadline DATE,
                status ENUM('pending', 'completed') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id))""",
            # Semesters table for academic periods
            """CREATE TABLE IF NOT EXISTS semesters (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                name VARCHAR(255) NOT NULL, start_date DATE NOT NULL, end_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id))""",
            # Classes table for course information
            """CREATE TABLE IF NOT EXISTS classes (
                id INT AUTO_INCREMENT PRIMARY KEY, semester_id INT NOT NULL,
                course_code VARCHAR(50) NOT NULL, course_name VARCHAR(255) NOT NULL,
                instructor VARCHAR(255), credits INT DEFAULT 3, color VARCHAR(7) DEFAULT '#3b82f6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE)""",
            # Class schedules table for weekly class timings
            """CREATE TABLE IF NOT EXISTS class_schedules (
                id INT AUTO_INCREMENT PRIMARY KEY, class_id INT NOT NULL,
                day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
                start_time TIME NOT NULL, end_time TIME NOT NULL, room VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE)""",
            # Attendance records table for tracking class attendance
            """CREATE TABLE IF NOT EXISTS attendance_records (
                id INT AUTO_INCREMENT PRIMARY KEY, class_id INT NOT NULL, date DATE NOT NULL,
                status ENUM('present','absent','late','excused') NOT NULL, notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE)"""
        ]
        
        # Loop through each table creation SQL statement
        for table_sql in tables:
            # Execute the SQL to create table
            cursor.execute(table_sql)
        
        # Commit all changes to database
        conn.commit()
        # Close the database cursor
        cursor.close()
        # Close the database connection
        conn.close()
        # Return True indicating success
        return True
    # Handle database errors during initialization
    except mysql.connector.Error as e:
        # Print error message to console
        print(f"Error initializing database: {e}")
        # Return False indicating failure
        return False

# Call init_db function to set up database when application starts
init_db()

# Define route for home page (both / and /home URLs)
@app.route('/') 
@app.route('/home')
# Define home page function
def home():
    """Home page showing upcoming tasks for logged-in users"""
    # Create empty list for upcoming tasks
    upcoming_tasks = []
    # Check if user is logged in by checking session
    if 'user' in session:
        # Try to fetch tasks from database
        try:
            # Get database connection
            conn = get_db_connection()
            # Create dictionary cursor to return rows as dictionaries
            cursor = conn.cursor(dictionary=True)
            # Execute SQL to get upcoming incomplete tasks for current user
            cursor.execute("SELECT * FROM tasks WHERE user_id = %s AND deadline >= CURDATE() AND status != 'completed' ORDER BY deadline ASC LIMIT 5", (session['user']['id'],))
            # Fetch all results into list
            upcoming_tasks = cursor.fetchall()
            # Close database cursor
            cursor.close()
            # Close database connection
            conn.close()
        # Handle database errors
        except mysql.connector.Error as e:
            # Print error to console
            print(f"Database error: {e}")
    # Render homepage template and pass upcoming tasks data
    return render_template('homepage.html', upcoming_tasks=upcoming_tasks)

# Define route for about page
@app.route('/about')
# Define about page function
def about():
    """About page"""
    # Render about page template
    return render_template('about.html')

# Define route for contact page
@app.route('/contact')
# Define contact page function
def contact():
    """Contact page"""
    # Render contact page template
    return render_template('contact.html')

# Define route for login page with GET and POST methods
@app.route('/login', methods=['GET', 'POST'])
# Define login function
def login():
    """User login handling"""
    # Check if user is already logged in
    if 'user' in session:
        # Redirect to home page if already logged in
        return redirect(url_for('home'))
    
    # Check if request method is POST (form submission)
    if request.method == 'POST':
        # Get email from form, strip whitespace, convert to lowercase
        email = request.form.get('email', '').strip().lower()
        # Get password from form
        password = request.form.get('password', '')
        # Check if remember me checkbox was checked
        remember_me = request.form.get('remember_me') == 'true'
        
        # Validate that both email and password are provided
        if not email or not password:
            # Flash error message to user
            flash('Please enter both email and password', 'error')
            # Re-render login page with error
            return render_template('login1.html')
        
        # Try to authenticate user
        try:
            # Get database connection
            conn = get_db_connection()
            # Create dictionary cursor
            cursor = conn.cursor(dictionary=True)
            # Execute SQL to find user with matching email and hashed password
            cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, hash_password(password)))
            # Fetch one matching user record
            user = cursor.fetchone()
            # Close cursor
            cursor.close()
            # Close connection
            conn.close()
            
            # Check if user was found
            if user:
                # Store user information in session
                session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
                # Set session permanence based on remember me choice
                session.permanent = remember_me
                # Flash success message
                flash('Login successful!', 'success')
                # Redirect to home page after successful login
                return redirect(url_for('home'))
            else:
                # Flash error message for invalid credentials
                flash('Invalid email or password', 'error')
        # Handle database errors during login
        except mysql.connector.Error as e:
            # Flash generic error message
            flash('An error occurred. Please try again.', 'error')
    
    # Render login page for GET requests or failed POST requests
    return render_template('login1.html')

# Define route for user registration
@app.route('/register', methods=['GET', 'POST'])
# Define registration function
def register():
    """User registration handling"""
    # Check if request method is POST (form submission)
    if request.method == 'POST':
        # Get username from form
        username = request.form.get('username')
        # Get email from form
        email = request.form.get('email')
        # Get password from form
        password = request.form.get('password')
        
        # Validate that all required fields are provided
        if not username or not email or not password:
            # Flash error message
            flash('All fields are required', 'error')
            # Redirect to login page with registration form shown
            return redirect(url_for('login', show='register'))
        
        # Validate password length
        if len(password) < 6:
            # Flash error message for short password
            flash('Password must be at least 6 characters long', 'error')
            # Redirect to login page with registration form shown
            return redirect(url_for('login', show='register'))
        
        # Try to register new user
        try:
            # Get database connection
            conn = get_db_connection()
            # Create cursor
            cursor = conn.cursor()
            # Check if user already exists with same email or username
            cursor.execute("SELECT id FROM users WHERE email = %s OR username = %s", (email, username))
            # Check if any user was found
            if cursor.fetchone():
                # Flash error message for duplicate user
                flash('User already exists with this email or username', 'error')
                # Redirect to login page with registration form
                return redirect(url_for('login', show='register'))
            
            # Insert new user into database
            cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, hash_password(password)))
            # Commit the transaction
            conn.commit()
            # Close cursor
            cursor.close()
            # Close connection
            conn.close()
            
            # Reconnect to get the newly created user data
            conn = get_db_connection()
            # Create dictionary cursor
            cursor = conn.cursor(dictionary=True)
            # Get the newly created user record
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            # Fetch the user data
            user = cursor.fetchone()
            # Close cursor
            cursor.close()
            # Close connection
            conn.close()
            
            # Store user information in session
            session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
            # Flash success message
            flash('Registration successful! Welcome to TrackSmart!', 'success')
            # Redirect to home page after successful registration
            return redirect(url_for('home'))
            
        # Handle database errors during registration
        except mysql.connector.Error as e:
            # Flash error message
            flash('Registration failed. Please try again.', 'error')
    
    # Redirect to login page with registration form for GET requests
    return redirect(url_for('login', show='register'))

# Define route for logout
@app.route('/logout')
# Define logout function
def logout():
    """Logout user by clearing session"""
    # Remove user data from session
    session.pop('user', None)
    # Flash logout message
    flash('You have been logged out.', 'info')
    # Redirect to home page after logout
    return redirect(url_for('home'))

# Define route for forgot password with GET and POST methods
@app.route('/forgot-password', methods=['GET', 'POST'])
# Define forgot password function
def forgot_password():
    """Handle password reset requests"""
    # Check if user is already logged in
    if 'user' in session:
        # Redirect to home if already logged in
        return redirect(url_for('home'))
    
    # Handle GET request (show form)
    if request.method == 'GET':
        # Render forgot password page
        return render_template('forgot_password.html')
    
    # Handle POST request (process form)
    # Get email from form
    email = request.form.get('email')
    # Validate email was provided
    if not email:
        # Flash error message
        flash('Please enter your email address', 'error')
        # Redirect to login page
        return redirect(url_for('login'))
    
    # Try to process password reset request
    try:
        # Get database connection
        conn = get_db_connection()
        # Create dictionary cursor
        cursor = conn.cursor(dictionary=True)
        # Find user by email
        cursor.execute("SELECT id, username FROM users WHERE email = %s", (email,))
        # Fetch user data
        user = cursor.fetchone()
        
        # Check if user exists
        if user:
            # Generate secure random token
            token = secrets.token_urlsafe(32)
            # Set token expiration to 1 hour from now
            expires_at = datetime.now() + timedelta(hours=1)
            # Store reset token in database
            cursor.execute("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (%s, %s, %s)", (user['id'], token, expires_at))
            # Commit transaction
            conn.commit()
            # Generate reset URL (in production, this would be sent via email)
            reset_url = url_for('reset_password', token=token, _external=True)
            # Print reset URL to console (for development)
            print(f"Password reset URL for {email}: {reset_url}")
        
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Flash info message (always show same message for security)
        flash('If an account with that email exists, a password reset link has been sent.', 'info')
        # Redirect to login page
        return redirect(url_for('login'))
    # Handle database errors
    except mysql.connector.Error as e:
        # Flash error message
        flash('An error occurred. Please try again.', 'error')
        # Redirect to login page
        return redirect(url_for('login'))

# Define route for password reset with token
@app.route('/reset-password/<token>', methods=['GET', 'POST'])
# Define reset password function
def reset_password(token):
    """Handle password reset with token"""
    # Handle GET request (show reset form)
    if request.method == 'GET':
        # Try to validate token
        try:
            # Get database connection
            conn = get_db_connection()
            # Create dictionary cursor
            cursor = conn.cursor(dictionary=True)
            # Verify token is valid, not expired, and not used
            cursor.execute("SELECT u.id, u.username FROM password_reset_tokens prt JOIN users u ON prt.user_id = u.id WHERE prt.token = %s AND prt.expires_at > NOW() AND prt.used = FALSE", (token,))
            # Fetch token data
            token_data = cursor.fetchone()
            # Close cursor
            cursor.close()
            # Close connection
            conn.close()
            
            # Check if token is valid
            if not token_data:
                # Flash error message for invalid token
                flash('Invalid or expired reset token.', 'error')
                # Redirect to login page
                return redirect(url_for('login'))
            
            # Render reset password page with token and username
            return render_template('reset_password.html', token=token, username=token_data['username'])
        # Handle database errors
        except mysql.connector.Error as e:
            # Flash error message
            flash('An error occurred. Please try again.', 'error')
            # Redirect to login page
            return redirect(url_for('login'))
    
    # Handle POST request (process password reset)
    else:
        # Get new password from form
        new_password = request.form.get('password')
        # Get password confirmation from form
        confirm_password = request.form.get('confirm_password')
        
        # Validate both passwords are provided
        if not new_password or not confirm_password:
            # Flash error message
            flash('Please fill in all fields', 'error')
            # Re-render reset page with error
            return render_template('reset_password.html', token=token)
        
        # Validate passwords match and meet length requirement
        if new_password != confirm_password or len(new_password) < 6:
            # Flash error message
            flash('Passwords do not match or are too short', 'error')
            # Re-render reset page with error
            return render_template('reset_password.html', token=token)
        
        # Try to reset password
        try:
            # Get database connection
            conn = get_db_connection()
            # Create dictionary cursor
            cursor = conn.cursor(dictionary=True)
            # Verify token is still valid
            cursor.execute("SELECT user_id FROM password_reset_tokens WHERE token = %s AND expires_at > NOW() AND used = FALSE", (token,))
            # Fetch token data
            token_data = cursor.fetchone()
            
            # Check if token is still valid
            if not token_data:
                # Flash error message
                flash('Invalid or expired reset token.', 'error')
                # Redirect to login page
                return redirect(url_for('login'))
            
            # Update user password with new hashed password
            cursor.execute("UPDATE users SET password = %s WHERE id = %s", (hash_password(new_password), token_data['user_id']))
            # Mark token as used
            cursor.execute("UPDATE password_reset_tokens SET used = TRUE WHERE token = %s", (token,))
            # Commit transaction
            conn.commit()
            # Close cursor
            cursor.close()
            # Close connection
            conn.close()
            
            # Flash success message
            flash('Your password has been reset successfully!', 'success')
            # Redirect to login page
            return redirect(url_for('login'))
        # Handle database errors
        except mysql.connector.Error as e:
            # Flash error message
            flash('An error occurred. Please try again.', 'error')
            # Re-render reset page with error
            return render_template('reset_password.html', token=token)

# Define route for tasks page
@app.route('/tasks')
# Define tasks function
def tasks():
    """Tasks management page"""
    # Check if user is logged in
    if 'user' not in session:
        # Flash warning message
        flash('Please log in first.', 'warning')
        # Redirect to login page
        return redirect(url_for('login'))
    # Render tasks page template
    return render_template('task.html')

# Define API endpoint to get tasks (GET method)
@app.route('/api/tasks', methods=['GET'])
# Define get tasks function
def get_tasks():
    """API endpoint to get all tasks for logged-in user"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to fetch tasks from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create dictionary cursor
        cursor = conn.cursor(dictionary=True)
        # Execute SQL to get all tasks for current user, ordered by deadline
        cursor.execute("SELECT * FROM tasks WHERE user_id = %s ORDER BY deadline ASC", (session['user']['id'],))
        # Fetch all tasks
        tasks = cursor.fetchall()
        
        # Process each task for JSON serialization
        for task in tasks:
            # Check if deadline exists
            if task['deadline']:
                # Convert date object to ISO format string
                task['deadline'] = task['deadline'].isoformat()
            # Ensure description is not None (convert to empty string if None)
            task['description'] = task['description'] or ''
        
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return tasks as JSON response
        return jsonify(tasks)
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to create task (POST method)
@app.route('/api/tasks', methods=['POST'])
# Define create task function
def create_task():
    """API endpoint to create new task"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Validate data exists and has title
    if not data or not data.get('title'):
        # Return JSON error with 400 status code
        return jsonify({'error': 'Title is required'}), 400
    
    # Try to create task in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Insert new task into database
        cursor.execute("INSERT INTO tasks (user_id, title, description, deadline) VALUES (%s, %s, %s, %s)", (session['user']['id'], data.get('title'), data.get('description', ''), data.get('deadline')))
        # Commit transaction
        conn.commit()
        # Get the ID of the newly created task
        task_id = cursor.lastrowid
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response with task ID
        return jsonify({'success': True, 'task_id': task_id})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to update task (PUT method)
@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
# Define update task function
def update_task(task_id):
    """API endpoint to update existing task"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Try to update task in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Verify task exists and belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        # Check if task was found
        if not cursor.fetchone():
            # Return JSON error with 404 status code
            return jsonify({'error': 'Task not found'}), 404
        
        # Update task with new data
        cursor.execute("UPDATE tasks SET title = %s, description = %s, deadline = %s WHERE id = %s", (data.get('title'), data.get('description'), data.get('deadline'), task_id))
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response
        return jsonify({'success': True})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to update task status (PUT method)
@app.route('/api/tasks/<int:task_id>/status', methods=['PUT'])
# Define update task status function
def update_task_status(task_id):
    """API endpoint to update task status only"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Get status from data
    status = data.get('status')
    
    # Validate status is either 'pending' or 'completed'
    if status not in ['pending', 'completed']:
        # Return JSON error with 400 status code
        return jsonify({'error': 'Invalid status'}), 400
    
    # Try to update task status in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Verify task exists and belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        # Check if task was found
        if not cursor.fetchone():
            # Return JSON error with 404 status code
            return jsonify({'error': 'Task not found'}), 404
        
        # Update only the status field
        cursor.execute("UPDATE tasks SET status = %s WHERE id = %s", (status, task_id))
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response
        return jsonify({'success': True})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to delete task (DELETE method)
@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
# Define delete task function
def delete_task(task_id):
    """API endpoint to delete task"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to delete task from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Verify task exists and belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        # Check if task was found
        if not cursor.fetchone():
            # Return JSON error with 404 status code
            return jsonify({'error': 'Task not found'}), 404
        
        # Delete the task from database
        cursor.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response
        return jsonify({'success': True})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define route for attendance page
@app.route('/attendance')
# Define attendance function
def attendance():
    """Attendance management page"""
    # Check if user is logged in
    if 'user' not in session:
        # Flash warning message
        flash('Please log in first.', 'warning')
        # Redirect to login page
        return redirect(url_for('login'))
    # Render attendance page template
    return render_template('attendance.html')

# Define API endpoint to get semesters (GET method)
@app.route('/api/semesters', methods=['GET'])
# Define get semesters function
def get_semesters():
    """API endpoint to get all semesters for logged-in user"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to fetch semesters from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create dictionary cursor
        cursor = conn.cursor(dictionary=True)
        # Execute SQL to get all semesters for current user, ordered by start date (newest first)
        cursor.execute("SELECT * FROM semesters WHERE user_id = %s ORDER BY start_date DESC", (session['user']['id'],))
        # Fetch all semesters
        semesters = cursor.fetchall()
        
        # Process each semester for JSON serialization
        for semester in semesters:
            # Convert start_date to ISO format string
            semester['start_date'] = semester['start_date'].isoformat()
            # Convert end_date to ISO format string
            semester['end_date'] = semester['end_date'].isoformat()
        
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return semesters as JSON response
        return jsonify(semesters)
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': 'Database error'}), 500

# Define API endpoint to create semester (POST method)
@app.route('/api/semesters', methods=['POST'])
# Define create semester function
def create_semester():
    """API endpoint to create new semester"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Validate required fields are present
    if not data or not all(key in data for key in ['name', 'start_date', 'end_date']):
        # Return JSON error with 400 status code
        return jsonify({'error': 'Name, start date, and end date are required'}), 400
    
    # Try to create semester in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Insert new semester into database
        cursor.execute("INSERT INTO semesters (user_id, name, start_date, end_date) VALUES (%s, %s, %s, %s)", (session['user']['id'], data['name'], data['start_date'], data['end_date']))
        # Commit transaction
        conn.commit()
        # Get the ID of the newly created semester
        semester_id = cursor.lastrowid
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response with semester ID
        return jsonify({'success': True, 'semester_id': semester_id})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to create class (POST method)
@app.route('/api/classes', methods=['POST'])
# Define create class function
def create_class():
    """API endpoint to create new class with schedules"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Validate required fields are present
    if not data or not all(key in data for key in ['semester_id', 'course_code', 'course_name']):
        # Return JSON error with 400 status code
        return jsonify({'error': 'Semester, course code, and course name are required'}), 400
    
    # Try to create class in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        # Insert new class into database
        cursor.execute("INSERT INTO classes (semester_id, course_code, course_name, instructor, credits, color) VALUES (%s, %s, %s, %s, %s, %s)", (data['semester_id'], data['course_code'], data['course_name'], data.get('instructor', ''), data.get('credits', 3), data.get('color', '#3b82f6')))
        # Get the ID of the newly created class
        class_id = cursor.lastrowid
        
        # Insert class schedules for the new class
        for schedule in data.get('schedules', []):
            # Insert each schedule into class_schedules table
            cursor.execute("INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)", (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', '')))
        
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        # Return success response with class ID
        return jsonify({'success': True, 'class_id': class_id})
    # Handle database errors
    except mysql.connector.Error as e:
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to get classes for a semester (GET method)
@app.route('/api/semesters/<int:semester_id>/classes', methods=['GET'])
# Define get classes function
def get_classes(semester_id):
    """API endpoint to get all classes for a specific semester with schedules and attendance stats"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to fetch classes from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create dictionary cursor
        cursor = conn.cursor(dictionary=True)
        
        # Get classes for the specified semester that belong to current user
        cursor.execute("""
            SELECT c.*, s.name as semester_name 
            FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.semester_id = %s AND s.user_id = %s
        """, (semester_id, session['user']['id']))
        # Fetch all classes
        classes = cursor.fetchall()
        
        # Process each class to add schedules and attendance stats
        for class_obj in classes:
            # Get schedules for this class, ordered by day and start time
            cursor.execute("""
                SELECT * FROM class_schedules 
                WHERE class_id = %s 
                ORDER BY 
                    FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
                    start_time
            """, (class_obj['id'],))
            # Fetch all schedules for this class
            schedules = cursor.fetchall()
            
            # Convert time objects to strings for JSON serialization
            for schedule in schedules:
                # Convert start_time to string
                schedule['start_time'] = str(schedule['start_time'])
                # Convert end_time to string
                schedule['end_time'] = str(schedule['end_time'])
            
            # Add schedules to class object
            class_obj['schedules'] = schedules
            
            # Get attendance statistics for this class
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_sessions,
                    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_count,
                    SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
                    SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_count,
                    SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) as excused_count
                FROM attendance_records 
                WHERE class_id = %s
            """, (class_obj['id'],))
            # Fetch attendance statistics
            stats = cursor.fetchone()
            
            # Process statistics, ensuring no None values
            if stats:
                # Add attendance stats to class object with default values for None
                class_obj['attendance_stats'] = {
                    'total_sessions': stats['total_sessions'] or 0,
                    'present_count': stats['present_count'] or 0,
                    'absent_count': stats['absent_count'] or 0,
                    'late_count': stats['late_count'] or 0,
                    'excused_count': stats['excused_count'] or 0
                }
            else:
                # Add default attendance stats if no records exist
                class_obj['attendance_stats'] = {
                    'total_sessions': 0,
                    'present_count': 0,
                    'absent_count': 0,
                    'late_count': 0,
                    'excused_count': 0
                }
        
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        
        # Return classes as JSON response
        return jsonify(classes)
        
    # Handle database errors
    except mysql.connector.Error as e:
        # Print error to console
        print(f"Database error: {e}")
        # Return JSON error with 500 status code
        return jsonify({'error': 'Database error'}), 500

# Define API endpoint to update class (PUT method)
@app.route('/api/classes/<int:class_id>', methods=['PUT'])
# Define update class function
def update_class(class_id):
    """API endpoint to update class information and schedules"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Validate data exists
    if not data:
        # Return JSON error with 400 status code
        return jsonify({'error': 'No data provided'}), 400
        
    # Extract class data from request
    course_code = data.get('course_code')
    course_name = data.get('course_name')
    instructor = data.get('instructor', '')
    credits = data.get('credits', 3)
    color = data.get('color', '#3b82f6')
    schedules = data.get('schedules', [])
    
    # Validate required fields
    if not course_code or not course_name:
        # Return JSON error with 400 status code
        return jsonify({'error': 'Course code and course name are required'}), 400
    
    # Try to update class in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        # Check if class was found
        if not cursor.fetchone():
            # Close cursor and connection
            cursor.close()
            conn.close()
            # Return JSON error with 404 status code
            return jsonify({'error': 'Class not found'}), 404
        
        # Update class information
        cursor.execute("""
            UPDATE classes 
            SET course_code = %s, course_name = %s, instructor = %s, credits = %s, color = %s
            WHERE id = %s
        """, (course_code, course_name, instructor, credits, color, class_id))
        
        # Delete existing schedules for this class
        cursor.execute("DELETE FROM class_schedules WHERE class_id = %s", (class_id,))
        
        # Insert new schedules
        for schedule in schedules:
            # Insert each new schedule
            cursor.execute(
                "INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)",
                (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', ''))
            )
        
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        
        # Return success response
        return jsonify({'success': True})
        
    # Handle database errors
    except mysql.connector.Error as e:
        # Print error to console
        print(f"Database error: {e}")
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to delete class (DELETE method)
@app.route('/api/classes/<int:class_id>', methods=['DELETE'])
# Define delete class function
def delete_class(class_id):
    """API endpoint to delete class and its related data"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to delete class from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        # Check if class was found
        if not cursor.fetchone():
            # Close cursor and connection
            cursor.close()
            conn.close()
            # Return JSON error with 404 status code
            return jsonify({'error': 'Class not found'}), 404
        
        # Delete class (cascade delete will handle schedules and attendance records)
        cursor.execute("DELETE FROM classes WHERE id = %s", (class_id,))
        
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        
        # Return success response
        return jsonify({'success': True})
        
    # Handle database errors
    except mysql.connector.Error as e:
        # Print error to console
        print(f"Database error: {e}")
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to record attendance (POST method)
@app.route('/api/attendance', methods=['POST'])
# Define record attendance function
def record_attendance():
    """API endpoint to record or update attendance for a class on specific date"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Get JSON data from request body
    data = request.get_json()
    # Validate data exists
    if not data:
        # Return JSON error with 400 status code
        return jsonify({'error': 'No data provided'}), 400
        
    # Extract attendance data from request
    class_id = data.get('class_id')
    date = data.get('date')
    status = data.get('status')
    notes = data.get('notes', '')
    
    # Validate required fields
    if not class_id or not date or not status:
        # Return JSON error with 400 status code
        return jsonify({'error': 'Class ID, date, and status are required'}), 400
    
    # Try to record attendance in database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create cursor
        cursor = conn.cursor()
        
        # Check if attendance already exists for this class and date
        cursor.execute(
            "SELECT id FROM attendance_records WHERE class_id = %s AND date = %s",
            (class_id, date)
        )
        # Fetch existing record if any
        existing_record = cursor.fetchone()
        
        # Check if record already exists
        if existing_record:
            # Update existing attendance record
            cursor.execute(
                "UPDATE attendance_records SET status = %s, notes = %s WHERE id = %s",
                (status, notes, existing_record[0])
            )
        else:
            # Insert new attendance record
            cursor.execute(
                "INSERT INTO attendance_records (class_id, date, status, notes) VALUES (%s, %s, %s, %s)",
                (class_id, date, status, notes)
            )
        
        # Commit transaction
        conn.commit()
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        
        # Return success response
        return jsonify({'success': True})
        
    # Handle database errors
    except mysql.connector.Error as e:
        # Print error to console
        print(f"Database error: {e}")
        # Return JSON error with 500 status code
        return jsonify({'error': f'Database error: {str(e)}'}), 500

# Define API endpoint to get class attendance (GET method)
@app.route('/api/classes/<int:class_id>/attendance', methods=['GET'])
# Define get class attendance function
def get_class_attendance(class_id):
    """API endpoint to get all attendance records for a specific class"""
    # Check if user is authenticated
    if 'user' not in session:
        # Return JSON error with 401 status code
        return jsonify({'error': 'Not authenticated'}), 401
    
    # Try to fetch attendance records from database
    try:
        # Get database connection
        conn = get_db_connection()
        # Create dictionary cursor
        cursor = conn.cursor(dictionary=True)
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        # Check if class was found
        if not cursor.fetchone():
            # Close cursor and connection
            cursor.close()
            conn.close()
            # Return JSON error with 404 status code
            return jsonify({'error': 'Class not found'}), 404
        
        # Get attendance records for this class, ordered by date (newest first)
        cursor.execute("""
            SELECT * FROM attendance_records 
            WHERE class_id = %s 
            ORDER BY date DESC
        """, (class_id,))
        
        # Fetch all attendance records
        attendance_records = cursor.fetchall()
        
        # Convert date objects to strings for JSON serialization
        for record in attendance_records:
            # Convert date to ISO format string
            record['date'] = record['date'].isoformat()
        
        # Close cursor
        cursor.close()
        # Close connection
        conn.close()
        
        # Return attendance records as JSON response
        return jsonify(attendance_records)
        
    # Handle database errors
    except mysql.connector.Error as e:
        # Print error to console
        print(f"Database error: {e}")
        # Return JSON error with 500 status code
        return jsonify({'error': 'Database error'}), 500

# Check if this script is being run directly (not imported)
if __name__ == '__main__':
    # Run the Flask application in debug mode
    app.run(debug=True)
    # debug=True enables auto-reload on code changes and detailed error pages