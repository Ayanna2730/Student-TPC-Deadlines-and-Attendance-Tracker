# **TrackSmart Flask Application - Complete Notes**

## **📋 APPLICATION OVERVIEW**
- **TrackSmart** is a student productivity web application built with Flask
- **Purpose**: Helps users manage academic life and tasks
- **Key Features**:
  - User authentication & sessions
  - Task management (CRUD operations)
  - Academic semester & class tracking
  - Class schedule management
  - Attendance recording & statistics

---

## **🔧 TECHNICAL ARCHITECTURE**

### **Framework & Pattern**
- **Framework**: Flask (Micro web framework)
- **Architecture**: MVC-like pattern
  - Models in database
  - Views in templates  
  - Controllers in routes
- **Database**: MySQL with mysql-connector-python
- **Template Engine**: Jinja2 for HTML rendering

### **Security Features**
- Password hashing with SHA-256
- Session-based authentication
- SQL injection prevention via parameterized queries
- Environment variable configuration

---

## **📦 IMPORTS BREAKDOWN**

### **1. FLASK FRAMEWORK COMPONENTS**
- **`Flask`** - Main application class that creates web server instance
- **`render_template`** - Renders HTML templates with dynamic data
- **`request`** - Handles incoming HTTP request data (forms, JSON, etc.)
- **`redirect`** - Redirects user to different routes
- **`url_for`** - Generates URLs for routes using function names
- **`session`** - Server-side user session storage (secure cookies)
- **`flash`** - Stores temporary messages for user feedback
- **`jsonify`** - Converts Python data to JSON responses for APIs

### **2. DATABASE & SECURITY**
- **`mysql.connector`** - MySQL database driver for database operations
- **`hashlib`** - Cryptographic hashing for password security
- **`secrets`** - Secure token generation for password resets

### **3. DATE/TIME HANDLING**
- **`datetime`** - Full date and time operations
- **`date`** - Date-only operations (no time component)
- **`timedelta`** - Time duration calculations

### **4. CONFIGURATION & ENVIRONMENT**
- **`os`** - Operating system interface for environment variables
- **`dotenv`** - Loads environment variables from .env file

---

## **🗄️ DATABASE SCHEMA**

### **Table Relationships**
- `users (1) → (many) tasks`
- `users (1) → (many) semesters`
- `users (1) → (many) password_reset_tokens`
- `semesters (1) → (many) classes`
- `classes (1) → (many) class_schedules`
- `classes (1) → (many) attendance_records`

### **Key Tables & Purpose**
- **`users`** - User accounts and authentication
- **`tasks`** - Personal task management
- **`semesters`** - Academic semester organization
- **`classes`** - Course information
- **`class_schedules`** - Weekly class timings
- **`attendance_records`** - Attendance tracking

---

## **🛣️ ROUTE ARCHITECTURE**

### **A. STATIC PAGES**
- `/`, `/home` - Homepage with upcoming tasks
- `/about` - About page
- `/contact` - Contact page

### **B. AUTHENTICATION ROUTES**
- `/login` - User login (GET for form, POST for processing)
- `/register` - User registration (GET for form, POST for processing)
- `/logout` - User logout
- `/forgot-password` - Password reset request
- `/reset-password/<token>` - Password reset with secure token

### **C. TASK MANAGEMENT ROUTES**
- `/tasks` - Tasks management page
- `/api/tasks` - Get all tasks (GET) / Create new task (POST)
- `/api/tasks/<id>` - Update (PUT) / Delete (DELETE) specific task
- `/api/tasks/<id>/status` - Update task status only (PUT)

### **D. ATTENDANCE SYSTEM ROUTES**
- `/attendance` - Attendance management page
- `/api/semesters` - Get all semesters (GET) / Create semester (POST)
- `/api/classes` - Create new class with schedules (POST)
- `/api/semesters/<id>/classes` - Get classes for specific semester (GET)
- `/api/classes/<id>` - Update (PUT) / Delete (DELETE) class
- `/api/attendance` - Record attendance for class (POST)
- `/api/classes/<id>/attendance` - Get attendance records for class (GET)

---

## **🔐 SECURITY IMPLEMENTATION**

### **Password Security**
- **Algorithm**: SHA-256 one-way hashing
- **Storage**: Only hashed passwords in database
- **Verification**: Hash input and compare with stored hash
- **Function**: `hash_password()` converts plain text to secure hash

### **Session Management**
- **Storage**: Server-side signed cookies
- **Persistence**: Configurable with "Remember Me" checkbox
- **Security**: Signed with `app.secret_key` from environment variables
- **Data**: Stores user ID, username, email in session

### **Password Reset Security**
- **Token Generation**: 32-byte cryptographically secure random tokens
- **Expiration**: 1-hour time limit using `timedelta`
- **Single Use**: Tokens marked as used after password reset
- **Verification**: Checks token validity and expiration before allowing reset

### **SQL Injection Prevention**
- **Method**: Parameterized queries with `%s` placeholders
- **Example**: `cursor.execute("SELECT * FROM users WHERE email = %s", (email,))`
- **Benefit**: Prevents malicious SQL injection attacks
- **Pattern**: Used throughout all database operations

---

## **📊 DATA FLOW PATTERNS**

### **Database Operation Pattern**
- Establish connection using `get_db_connection()`
- Create cursor with `dictionary=True` for named columns
- Execute query with parameterized inputs
- Fetch results using `fetchone()` or `fetchall()`
- Commit changes for write operations
- Close cursor and connection
- Handle exceptions with try-catch blocks

### **Authentication Flow**
- User submits login form with email and password
- Server hashes password and queries database for matching user
- If valid, create session with user data
- Set session permanence based on "Remember Me" selection
- Redirect to home page with success message
- Subsequent requests check session for authentication

### **API Response Pattern**
- Check user authentication via session
- Process request data from `request.get_json()`
- Validate required fields and input data
- Perform database operations
- Return JSON response with success/error status
- Handle errors with appropriate HTTP status codes

---

## **🎯 KEY FEATURES IMPLEMENTATION**

### **User System**
- Registration with field validation and duplicate checking
- Login system with "Remember Me" functionality
- Secure logout that clears session data
- Complete password reset flow with email tokens

### **Task Management**
- Full CRUD operations (Create, Read, Update, Delete)
- Status tracking with pending/completed states
- Deadline management with date validation
- User-specific task isolation and security

### **Academic System**
- Semester creation and organization
- Class creation with detailed course information
- Schedule management with day/time tracking
- Color-coding system for visual organization
- Attendance statistics calculation and reporting

### **Attendance Tracking**
- Multiple status types: present, absent, late, excused
- Date-specific attendance recording
- Notes field for additional context
- Statistical reporting with counts and percentages
- Update existing attendance records

---

## **⚙️ CONFIGURATION MANAGEMENT**

### **Environment Variables (.env)**
- `SECRET_KEY` - Flask session signing key
- `MYSQL_HOST` - Database server hostname
- `MYSQL_USER` - Database username
- `MYSQL_PASSWORD` - Database password
- `MYSQL_DB` - Database name

### **Application Configuration**
- Static files served from `static/` folder
- HTML templates loaded from `templates/` folder
- Secret key loaded from environment with fallback
- Database autocommit enabled for automatic transaction handling

---

## **🚀 DEPLOYMENT & RUNNING**

### **Development Execution**
- Run with `python app.py`
- Server starts on `http://localhost:5000`
- Debug mode enabled for development
- Automatic reload on code changes

### **Startup Processes**
- Load environment variables from .env file
- Initialize Flask application instance
- Create database connection pool
- Initialize database tables if they don't exist
- Start web server and listen for requests

---

## **📝 BEST PRACTICES USED**

### **Security Best Practices**
- Password hashing instead of plain text storage
- SQL injection prevention through parameterized queries
- Secure session management with signed cookies
- Environment variables for sensitive configuration
- Input validation and sanitization

### **Code Organization**
- Separation of concerns between routes, database, utilities
- Consistent error handling patterns throughout
- DRY principles with helper functions for common operations
- Clear and descriptive route naming conventions
- Comprehensive code commenting

### **User Experience Features**
- Flash messages for immediate user feedback
- JSON APIs for dynamic frontend functionality
- Responsive error handling with user-friendly messages
- Session persistence options for convenience
- Consistent navigation and workflow

---

## **🔮 POTENTIAL ENHANCEMENTS**

### **Immediate Improvements**
- Email integration for actual password reset delivery
- Input sanitization for user-generated content
- Rate limiting on authentication endpoints
- Data validation using WTForms library
- Password strength requirements

### **Advanced Features**
- Task categories, priorities, and tags
- Class grade tracking and GPA calculation
- Export functionality for PDF/Excel reports
- Mobile-responsive design improvements
- Real-time notifications and reminders
- Calendar integration and sync
- File uploads for assignment submissions
- Progress tracking and analytics
- Multi-language support
- API documentation with Swagger

This architecture provides a **solid foundation** for a student productivity application with comprehensive features and room for scaling and future enhancements!

how did you implement  the crud functionality ?
I built full CRUD operations in TrackSmart where users can create new tasks and classes, read their existing data, update information when things change, and delete items they no longer need, with all these actions protected by secure login verification to keep each user's data safe and separate.

How to create links or routes?

Links:
<!-- Basic link to another page -->
<a href="/about">About Us</a>

<!-- Link using url_for (recommended) -->
<a href="{{ url_for('home') }}">Home</a>
<a href="{{ url_for('contact') }}">Contact</a>

<!-- Link with parameters -->
<a href="{{ url_for('show_user', username='john') }}">John's Profile</a>

<!-- Link in navigation menu -->
<nav>
    <a href="{{ url_for('home') }}">Home</a>
    <a href="{{ url_for('about') }}">About</a>
    <a href="{{ url_for('contact') }}">Contact</a>
</nav>

Routes:
from flask import Flask, render_template

app = Flask(__name__)

# Simple route
@app.route('/')
def home():
    return 'Home Page'

# Route with multiple URLs
@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')

# Route with parameters
@app.route('/user/<username>')
def show_user(username):
    return f'Hello {username}'

# Route with specific HTTP methods
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Handle login
        return 'Logged in!'
    else:
        # Show login form
        return render_template('login.html')

how oop pillars  was integrated  in ur program?
I used four important programming ideas in my TrackSmart system. First, I used **encapsulation** to keep private data safe inside functions - like passwords and database connections. Second, I used **abstraction** to make complicated things simple - users see easy buttons but don't see the hard work happening behind them.

Third, I used **inheritance** to make different parts follow the same rules - like all pages checking if users are logged in. Fourth, I used **polymorphism** to make one function handle different situations - like the same attendance button working for different class types. These ideas helped me build a strong and organized system.