from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
import hashlib
from datetime import datetime, date, timedelta
import secrets

APP_SECRET = "your-secret-key-here"   


app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = APP_SECRET


def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="#hp_2024aleah",
            database="tracksmart"
        )
        return conn
    except Error as e:
        print("Error while connecting to MySQL:", e)
        return None


def hash_password(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def ensure_db():    
    base = mysql.connector.connect(host="localhost", user="root", password="#hp-2024aleah")
    cur = base.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {"tracksmart"}")
    cur.close(); base.close()

    
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          username VARCHAR(100) NOT NULL,
          email VARCHAR(255) NOT NULL UNIQUE,
          password VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB;
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          title VARCHAR(255) NOT NULL,
          description TEXT,
          deadline DATE,
          status ENUM('pending','completed') DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          INDEX(user_id), INDEX(deadline)
        ) ENGINE=InnoDB;
    """)

    conn.commit()
    cur.close(); conn.close()

ensure_db()


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        email    = (request.form.get('email') or '').strip().lower()
        password = request.form.get('password') or ''

        if not username or not email or not password:
            flash('All fields are required.', 'warning')
            return redirect(url_for('register'))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'warning')
            # return redirect(url_for('register'))

        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT id FROM users WHERE email=%s OR username=%s", (email, username))
        if cur.fetchone():
            flash('User already exists with this email or username.', 'danger')
            cur.close(); conn.close()
            return redirect(url_for('register'))

        cur.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                    (username, email, hash_password(password)))
        conn.commit()

        
        cur.execute("SELECT id, username, email FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close(); conn.close()

        session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
        flash('Registration successful!', 'success')
        return redirect(url_for('home'))

    return render_template('login1.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user' in session:
        return redirect(url_for('home'))

    if request.method == 'POST':
        email    = (request.form.get('email') or '').strip().lower()
        password = request.form.get('password') or ''

        if not email or not password:
            flash('Please enter both email and password.', 'warning')
            return redirect(url_for('login'))

        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close(); conn.close()

        if user and user['password'] == hash_password(password):
            session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password.', 'danger')
            return redirect(url_for('login'))

    return render_template('login1.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))
@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    # If already logged in, go home
    if 'user' in session:
        return redirect(url_for('home'))

    # Show form
    if request.method == 'GET':
        return render_template('forgot_password.html')

    # Handle submit (POST)
    email = (request.form.get('email') or '').strip().lower()
    if not email:
        flash('Please enter your email address.', 'error')
        return redirect(url_for('forgot_password'))

    try:
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)

        # Check if the user exists
        cur.execute("SELECT id, username FROM users WHERE email = %s", (email,))
        user = cur.fetchone()

        # Always show the same message (don’t reveal if email exists)
        flash('If an account with that email exists, a password reset link has been sent.', 'info')

        # If no user, we’re done
        if not user:
            cur.close(); conn.close()
            return redirect(url_for('login'))

        # Create a token and store it
        token = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(hours=1)
        cur.execute(
            "INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (%s, %s, %s)",
            (user['id'], token, expires_at)
        )
        conn.commit()

        # In real app: send email. For now, print the link:
        reset_url = url_for('reset_password', token=token, _external=True)
        print(f"[DEBUG] Password reset URL for {email}: {reset_url}")

        cur.close(); conn.close()
        return redirect(url_for('login'))

    except mysql.connector.Error as e:
        print("DB error:", e)
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('forgot_password'))

@app.route('/')
@app.route('/home')
def home():
    upcoming = []
    if 'user' in session:
        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT id, title, description, deadline, status
            FROM tasks
            WHERE user_id=%s
              AND (deadline IS NULL OR deadline >= CURDATE())
              AND status <> 'completed'
            ORDER BY deadline IS NULL, deadline ASC
            LIMIT 5
        """, (session['user']['id'],))
        upcoming = cur.fetchall()
        cur.close(); conn.close()
    return render_template('homepage.html', upcoming_tasks=upcoming)


@app.route('/tasks')
def tasks_list():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT id, title, description, deadline, status, created_at
        FROM tasks
        WHERE user_id=%s
        ORDER BY
          CASE WHEN status='pending' THEN 0 ELSE 1 END,
          deadline IS NULL, deadline ASC, id DESC
    """, (session['user']['id'],))
    rows = cur.fetchall()
    cur.close(); conn.close()
    return render_template('task_list.html', tasks=rows)

@app.route('/tasks/new', methods=['GET', 'POST'])
def tasks_new():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = (request.form.get('title') or '').strip()
        description = (request.form.get('description') or '').strip()
        deadline = request.form.get('deadline') or None
        if not title:
            flash('Title is required.', 'warning')
            return redirect(url_for('tasks_new'))

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO tasks (user_id, title, description, deadline) VALUES (%s, %s, %s, %s)",
            (session['user']['id'], title, description, deadline)
        )
        conn.commit()
        cur.close(); conn.close()
        flash('Task created!', 'success')
        return redirect(url_for('tasks_list'))

    return render_template('task_form.html', action='Create', task=None, today=date.today().isoformat())

@app.route('/tasks/<int:task_id>/edit', methods=['GET', 'POST'])
def tasks_edit(task_id):
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    if request.method == 'POST':
        title = (request.form.get('title') or '').strip()
        description = (request.form.get('description') or '').strip()
        deadline = request.form.get('deadline') or None
        status = request.form.get('status') or 'pending'
        if not title:
            flash('Title is required.', 'warning')
            cur.close(); conn.close()
            return redirect(url_for('tasks_edit', task_id=task_id))

        # task per user
        cur.execute("SELECT id FROM tasks WHERE id=%s AND user_id=%s", (task_id, session['user']['id']))
        if not cur.fetchone():
            flash('Task not found.', 'danger')
            cur.close(); conn.close()
            return redirect(url_for('tasks_list'))

        cur.execute("""
            UPDATE tasks
            SET title=%s, description=%s, deadline=%s, status=%s
            WHERE id=%s
        """, (title, description, deadline, status, task_id))
        conn.commit()
        cur.close(); conn.close()
        flash('Task updated!', 'success')
        return redirect(url_for('tasks_list'))

    
    cur.execute("SELECT * FROM tasks WHERE id=%s AND user_id=%s", (task_id, session['user']['id']))
    task = cur.fetchone()
    cur.close(); conn.close()
    if not task:
        flash('Task not found.', 'danger')
        return redirect(url_for('tasks_list'))

    return render_template('task_form.html', action='Update', task=task, today=date.today().isoformat())

@app.route('/tasks/<int:task_id>/delete', methods=['POST'])
def tasks_delete(task_id):
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM tasks WHERE id=%s AND user_id=%s", (task_id, session['user']['id']))
    conn.commit()
    cur.close(); conn.close()
    flash('Task deleted.', 'info')
    return redirect(url_for('tasks_list'))

@app.route('/attendance') 
def attendance(): 
    if 'user' not in session: 
        flash('Please log in first.', 'warning')
        return redirect(url_for('login')) 
    return render_template('attendance.html')

if __name__ == '_main_':
    app.run(debug=True)