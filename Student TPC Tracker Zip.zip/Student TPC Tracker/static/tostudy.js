// Main JavaScript for common functionality

// Wait for the DOM to be fully loaded before executing any code
document.addEventListener('DOMContentLoaded', function() {
    // Consolidated hamburger menu toggle functionality for mobile navigation
    const menuBtn = document.getElementById('hamburger-toggle');  // Use the new ID for precision
    const navMenu = document.querySelector('.navbar-menu');
    
    if (menuBtn && navMenu) {
        menuBtn.addEventListener('click', function(event) {
            event.preventDefault();  // Prevent any default behavior (like page refresh)
            event.stopPropagation();  // Stop event from bubbling up to parent elements
            console.log('Hamburger button clicked');  // For debugging purposes
            menuBtn.classList.toggle('active');  // Toggle active class for animation
            navMenu.classList.toggle('active');  // Show/hide the navigation menu
        });
    } else {
        console.error('Hamburger button or menu not found');  // Log if elements are missing
    }
    
    // Close menu when clicking anywhere outside of it
    document.addEventListener('click', function(event) {
        if (navMenu.classList.contains('active') && 
            !event.target.closest('.navbar-toggle') &&  // Not clicking on toggle button
            !event.target.closest('.navbar-menu')) {    // Not clicking inside menu
            navMenu.classList.remove('active');
            menuBtn.classList.remove('active');
        }
    });
    
    // Close menu when pressing Escape key (keyboard accessibility)
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            menuBtn.classList.remove('active');
        }
    });

    // Auto-hide flash messages (success/error notifications) after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.display = 'none';  // Hide the alert element
        });
    }, 5000);

    // Initialize tasks functionality only if on tasks page
    if (document.getElementById('taskList')) {
        initializeTasks();
    }

    // Initialize auth functionality only if on login page
    if (document.getElementById('loginForm')) {
        initializeAuth();
    }
});

// Authentication form handling - manages login/register form switching
document.addEventListener('DOMContentLoaded', function() {
    // Fix form switching functionality between login and register forms
    const wrapper = document.querySelector('.wrapper');  // Container that holds both forms
    const registerLink = document.querySelector('.register-link');  // "Register" link
    const loginLink = document.querySelector('.login-link');  // "Login" link
    
    console.log('Form switching elements:', { wrapper, registerLink, loginLink });

    if (registerLink && loginLink && wrapper) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();  // Prevent default link behavior
            console.log('Switching to register form');
            wrapper.classList.add('active');  // Show register form
        });

        loginLink.addEventListener('click', function(e) {
            e.preventDefault();  // Prevent default link behavior
            console.log('Switching to login form');
            wrapper.classList.remove('active');  // Show login form
        });
    } else {
        console.error('Form switching elements not found');
    }

    // Check URL parameters for form display (e.g., ?show=register)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('show') === 'register') {
        console.log('Showing register form from URL parameter');
        if (wrapper) {
            wrapper.classList.add('active');  // Show register form
        }
    }

    // Mobile menu toggle functionality (alternative implementation)
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (navbarToggle && navbarMenu) {
        navbarToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
            navbarToggle.classList.toggle('active');
        });
    }

    // Close mobile menu when clicking on a navigation link
    const navLinks = document.querySelectorAll('.navbar-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navbarToggle && navbarMenu) {
                navbarToggle.classList.remove('active');
                navbarMenu.classList.remove('active');
            }
        });
    });

    // Auto-hide flash messages after 5 seconds (duplicate for safety)
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.display = 'none';
        });
    }, 5000);

    // Initialize tasks functionality if on tasks page
    if (document.getElementById('taskList')) {
        initializeTasks();
    }

    // Initialize attendance functionality if on attendance page
    if (document.getElementById('attendanceContainer')) {
        initializeAttendance();
    }
});

// ============================================================================
// TASK MANAGEMENT SYSTEM
// ============================================================================

// Global variables to store task data and track current operation
let tasks = [];  // Array to store all tasks
let currentTaskId = null;  // Track which task is being edited/deleted

// Initialize task management system
function initializeTasks() {
    loadTasks();  // Load tasks from server
    setupTaskEventListeners();  // Set up all button click handlers
}

// Set up all event listeners for task-related interactions
function setupTaskEventListeners() {
    // Modal controls - elements that open/close popup windows
    const addTaskBtn = document.getElementById('addTaskBtn');  // "Add Task" button
    const closeModalBtn = document.getElementById('closeModal');  // Close button (X)
    const cancelTaskBtn = document.getElementById('cancelTask');  // Cancel button
    const taskForm = document.getElementById('taskForm');  // The task form itself
    
    // Delete modal controls
    const cancelDeleteBtn = document.getElementById('cancelDelete');  // Cancel delete
    const confirmDeleteBtn = document.getElementById('confirmDelete');  // Confirm delete
    
    // Add event listeners to handle user interactions
    if (addTaskBtn) addTaskBtn.addEventListener('click', openCreateModal);
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeTaskModal);
    if (cancelTaskBtn) cancelTaskBtn.addEventListener('click', closeTaskModal);
    if (taskForm) taskForm.addEventListener('submit', saveTask);  // Form submission
    
    if (cancelDeleteBtn) cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    if (confirmDeleteBtn) confirmDeleteBtn.addEventListener('click', confirmDeleteTask);
    
    // Filter tabs - show different task views (All, Pending, Completed, Overdue)
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            this.classList.add('active');
            // Filter tasks based on the selected tab
            filterTasks(this.dataset.filter);
        });
    });

    // Close modal when clicking outside of it (on the overlay)
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {  // If clicked directly on modal background (not content)
                this.style.display = 'none';  // Hide the modal
            }
        });
    });
}

// Load tasks from the server via API call
async function loadTasks() {
    try {
        console.log('Loading tasks...');
        const response = await fetch('/api/tasks');  // Make GET request to tasks API
        
        if (response.status === 401) {
            console.log('User not authenticated, redirecting to login...');
            showError('Please log in to view tasks');
            window.location.href = '/login';  // Redirect to login page
            return;
        }
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Failed to load tasks:', response.status, errorText);
            showError('Failed to load tasks. Please try again.');
            return;
        }
        
        const tasksData = await response.json();  // Parse JSON response
        
        // Handle case where API returns error object instead of task list
        if (tasksData.error) {
            console.error('API returned error:', tasksData.error);
            showError('Failed to load tasks: ' + tasksData.error);
            return;
        }
        
        tasks = tasksData;  // Store tasks in global variable
        console.log('Tasks loaded successfully:', tasks);
        
        // Ensure all tasks have the required fields with default values
        tasks = tasks.map(task => ({
            id: task.id,
            title: task.title || '',
            description: task.description || '',
            deadline: task.deadline || null,
            status: task.status || 'pending',
            created_at: task.created_at
        }));
        
        renderTasks();  // Display tasks in the UI
        updateTaskStats();  // Update the statistics counters
        
    } catch (error) {
        console.error('Error loading tasks:', error);
        showError('Error loading tasks. Please check your connection.');
    }
}

// Display tasks in the task list container
function renderTasks() {
    const taskList = document.getElementById('taskList');
    if (!taskList) return;  // Exit if element doesn't exist
    
    taskList.innerHTML = '';  // Clear current task list

    if (tasks.length === 0) {
        // Show message when no tasks exist
        taskList.innerHTML = '<div class="no-tasks">No tasks found. Create your first task!</div>';
        return;
    }

    // Create and append HTML element for each task
    tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        taskList.appendChild(taskElement);
    });
}

// Create HTML element for a single task
function createTaskElement(task) {
    const taskDiv = document.createElement('div');
    
    // Determine task classes based on status and overdue state
    const isCompleted = task.status === 'completed';
    const isOverdue = isTaskOverdue(task);
    
    let taskClasses = ['task-card'];  // Base CSS class
    if (isCompleted) taskClasses.push('completed');  // Add completed styling
    if (isOverdue) taskClasses.push('overdue');  // Add overdue styling
    
    taskDiv.className = taskClasses.join(' ');  // Combine all classes
    taskDiv.dataset.taskId = task.id;  // Store task ID as data attribute
    
    // Format the deadline date for display
    const formattedDate = task.deadline ? new Date(task.deadline).toLocaleDateString() : 'No deadline';
    
    // Create the HTML structure for the task card
    taskDiv.innerHTML = `
        <div class="task-header">
            <div class="task-title ${isCompleted ? 'completed' : ''}">${escapeHtml(task.title)}</div>
            <div class="task-actions">
                <button class="icon-btn edit-btn" onclick="openEditModal(${task.id})" title="Edit task">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="icon-btn delete-btn" onclick="openDeleteModal(${task.id})" title="Delete task">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        ${task.description ? `<div class="task-description ${isCompleted ? 'completed' : ''}">${escapeHtml(task.description)}</div>` : ''}
        <div class="task-footer">
            <span class="task-deadline ${isOverdue && !isCompleted ? 'overdue' : ''}">
                <i class="fas fa-calendar"></i> ${formattedDate}
            </span>
        </div>
        <div class="task-status">
            <label class="checkbox-container">
                <input type="checkbox" ${isCompleted ? 'checked' : ''} onchange="toggleTaskStatus(${task.id})">
                <span class="checkmark"></span>
                <span class="status-text">${isCompleted ? 'Completed' : 'Mark as Complete'}</span>
            </label>
        </div>
    `;
    
    return taskDiv;
}

// Check if a task is overdue (past deadline and not completed)
function isTaskOverdue(task) {
    if (!task.deadline || task.status === 'completed') return false;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);  // Set to start of day for accurate comparison
    const taskDate = new Date(task.deadline);
    taskDate.setHours(0, 0, 0, 0);
    
    return taskDate < today;  // True if deadline is before today
}

// Update the task statistics counters in the UI
function updateTaskStats() {
    const totalTasks = tasks.length;
    const pendingTasks = tasks.filter(task => task.status === 'pending').length;
    const completedTasks = tasks.filter(task => task.status === 'completed').length;
    const overdueTasks = tasks.filter(task => isTaskOverdue(task)).length;
    
    // Get DOM elements for each statistic
    const totalTasksEl = document.getElementById('totalTasks');
    const pendingTasksEl = document.getElementById('pendingTasks');
    const completedTasksEl = document.getElementById('completedTasks');
    const overdueTasksEl = document.getElementById('overdueTasks');
    
    // Update the text content of each element
    if (totalTasksEl) totalTasksEl.textContent = totalTasks;
    if (pendingTasksEl) pendingTasksEl.textContent = pendingTasks;
    if (completedTasksEl) completedTasksEl.textContent = completedTasks;
    if (overdueTasksEl) overdueTasksEl.textContent = overdueTasks;
}

// Filter tasks based on the selected filter type
function filterTasks(filter) {
    const taskCards = document.querySelectorAll('.task-card');
    
    taskCards.forEach(card => {
        const taskId = parseInt(card.dataset.taskId);
        const task = tasks.find(t => t.id === taskId);
        
        if (!task) return;  // Skip if task not found
        
        let shouldShow = true;  // Default to showing task
        
        switch (filter) {
            case 'pending':
                shouldShow = task.status === 'pending';
                break;
            case 'completed':
                shouldShow = task.status === 'completed';
                break;
            case 'overdue':
                shouldShow = isTaskOverdue(task);
                break;
            default: // 'all'
                shouldShow = true;
        }
        
        // Show or hide the task card based on filter
        card.style.display = shouldShow ? 'block' : 'none';
    });
}

// Open the modal for creating a new task
function openCreateModal() {
    const modal = document.getElementById('taskModal');
    const modalTitle = document.getElementById('modalTitle');
    const taskForm = document.getElementById('taskForm');
    
    if (modal && modalTitle && taskForm) {
        modalTitle.textContent = 'Create Task';
        taskForm.reset();  // Clear any existing form data
        document.getElementById('taskId').value = '';  // Clear task ID
        
        // Set default date to today for convenience
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('taskDate').value = today;
        
        currentTaskId = null;  // Reset current task ID (creating new task)
        modal.style.display = 'block';  // Show the modal
    }
}

// Open the modal for editing an existing task
function openEditModal(taskId) {
    const task = tasks.find(t => t.id === taskId);  // Find task by ID
    const modal = document.getElementById('taskModal');
    const modalTitle = document.getElementById('modalTitle');
    
    if (task && modal && modalTitle) {
        modalTitle.textContent = 'Edit Task';
        // Populate form fields with existing task data
        document.getElementById('taskId').value = task.id;
        document.getElementById('taskName').value = task.title || '';
        document.getElementById('taskDescript').value = task.description || '';
        document.getElementById('taskDate').value = task.deadline ? task.deadline.split('T')[0] : '';
        currentTaskId = taskId;  // Set current task ID for update operation
        modal.style.display = 'block';  // Show the modal
    }
}

// Open the confirmation modal for deleting a task
function openDeleteModal(taskId) {
    currentTaskId = taskId;  // Store which task to delete
    const modal = document.getElementById('deleteModal');
    if (modal) {
        modal.style.display = 'block';  // Show delete confirmation modal
    }
}

// Save task (both create and update operations)
async function saveTask(e) {
    e.preventDefault();  // Prevent form from submitting normally
    
    // Get form values
    const title = document.getElementById('taskName').value;
    const description = document.getElementById('taskDescript').value;
    const deadline = document.getElementById('taskDate').value;
    
    if (!title.trim()) {
        showError('Task title is required');
        return;
    }
    
    // Prepare data for API call
    const taskData = {
        title: title.trim(),
        description: description.trim(),
        deadline: deadline
    };
    
    // Determine URL and HTTP method based on whether we're creating or updating
    const url = currentTaskId ? `/api/tasks/${currentTaskId}` : '/api/tasks';
    const method = currentTaskId ? 'PUT' : 'POST';
    
    try {
        console.log('Saving task:', taskData, 'URL:', url, 'Method:', method);
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'  // Tell server we're sending JSON
            },
            body: JSON.stringify(taskData)  // Convert object to JSON string
        });
        
        if (response.ok) {
            closeTaskModal();
            await loadTasks(); // Wait for reload to complete before showing success
            showSuccess(currentTaskId ? 'Task updated successfully!' : 'Task created successfully!');
        } else {
            const errorData = await response.json();
            console.error('Failed to save task:', errorData);
            showError('Failed to save task: ' + (errorData.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error saving task:', error);
        showError('Error saving task. Please try again.');
    }
}

// Toggle task status between pending and completed
async function toggleTaskStatus(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
        console.error('Task not found:', taskId);
        showError('Task not found');
        return;
    }
    
    // Determine new status (toggle between completed and pending)
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    
    try {
        console.log('Updating task status:', taskId, 'to:', newStatus);
        const response = await fetch(`/api/tasks/${taskId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: newStatus
            })
        });
        
        if (response.ok) {
            // Update local task state immediately for better user experience
            task.status = newStatus;
            renderTasks();  // Re-render the task list
            updateTaskStats();  // Update statistics
            showSuccess(`Task marked as ${newStatus}!`);
        } else {
            const errorData = await response.json();
            console.error('Failed to update task status:', errorData);
            showError('Failed to update task status: ' + (errorData.error || 'Unknown error'));
            // Reload tasks to ensure sync with server
            await loadTasks();
        }
    } catch (error) {
        console.error('Error updating task status:', error);
        showError('Error updating task status. Please try again.');
        // Reload tasks to ensure sync with server
        await loadTasks();
    }
}

// Delete a task after confirmation
async function confirmDeleteTask() {
    if (!currentTaskId) {
        console.error('No task ID selected for deletion');
        return;
    }
    
    try {
        console.log('Deleting task:', currentTaskId);
        const response = await fetch(`/api/tasks/${currentTaskId}`, {
            method: 'DELETE'  // HTTP DELETE request
        });
        
        if (response.ok) {
            closeDeleteModal();
            await loadTasks();  // Reload updated task list
            showSuccess('Task deleted successfully!');
        } else {
            const errorData = await response.json();
            console.error('Failed to delete task:', errorData);
            showError('Failed to delete task: ' + (errorData.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error deleting task:', error);
        showError('Error deleting task. Please try again.');
    }
}

// Close the task creation/editing modal
function closeTaskModal() {
    const modal = document.getElementById('taskModal');
    if (modal) {
        modal.style.display = 'none';  // Hide the modal
    }
}

// Close the delete confirmation modal
function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    if (modal) {
        modal.style.display = 'none';  // Hide the modal
    }
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

// Prevent XSS attacks by escaping HTML special characters
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")   // Escape ampersand
        .replace(/</g, "&lt;")    // Escape less than
        .replace(/>/g, "&gt;")    // Escape greater than
        .replace(/"/g, "&quot;")  // Escape double quotes
        .replace(/'/g, "&#039;"); // Escape single quotes
}

// Show success notification toast
function showSuccess(message) {
    // Create a toast notification element
    const toast = document.createElement('div');
    toast.className = 'toast success';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);  // Add to page
    
    // Remove toast after 3 seconds automatically
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 3000);
}

// Show error notification toast
function showError(message) {
    // Create a toast notification element
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);  // Add to page
    
    // Remove toast after 3 seconds automatically
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 3000);
}

// Inject toast styles only once (prevents duplicate styles)
if (!document.querySelector('#toast-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'toast-styles';
    styleSheet.textContent = `
    .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 4px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .toast.success {
        background-color: #28a745;  /* Green for success */
    }

    .toast.error {
        background-color: #dc3545;  /* Red for errors */
    }

    .toast-content {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);  /* Start off-screen to the right */
            opacity: 0;
        }
        to {
            transform: translateX(0);     /* Slide into position */
            opacity: 1;
        }
    }`;
    document.head.appendChild(styleSheet);  // Add styles to page
}

// ============================================================================
// ATTENDANCE MANAGEMENT SYSTEM
// ============================================================================

// Global variables for attendance system
let currentSemester = null;      // Currently selected semester
let currentWeekStart = null;     // Start date of current week view
let classes = [];                // Array of classes for current semester
let classToDelete = null;        // Track which class is being deleted

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing attendance system...');
    initializeAttendance();
    setupEventListeners();
    loadSemesters();  // Load available semesters
});

// Set up the attendance system with default values
function initializeAttendance() {
    // Set current week to today's week
    const today = new Date();
    currentWeekStart = getWeekStart(today);  // Calculate start of current week
    updateWeekDisplay();  // Update week range in UI
    loadWeeklyCalendar(); // Load the weekly class schedule
}

// Set up all event listeners for attendance system
function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    // Modal controls
    const addSemesterBtn = document.getElementById('addSemesterBtn');
    if (addSemesterBtn) {
        addSemesterBtn.addEventListener('click', showSemesterSelectModal);
    } else {
        console.error('Add semester button not found');
    }
    
    const addNewSemesterBtn = document.getElementById('addNewSemesterBtn');
    if (addNewSemesterBtn) {
        addNewSemesterBtn.addEventListener('click', showSemesterModal);
    }
    
    // Week navigation buttons
    const prevWeekBtn = document.getElementById('prevWeek');
    const nextWeekBtn = document.getElementById('nextWeek');
    if (prevWeekBtn) prevWeekBtn.addEventListener('click', goToPreviousWeek);
    if (nextWeekBtn) nextWeekBtn.addEventListener('click', goToNextWeek);
    
    // Form submissions
    const semesterForm = document.getElementById('semesterForm');
    const classForm = document.getElementById('classForm');
    const attendanceForm = document.getElementById('attendanceForm');
    
    if (semesterForm) semesterForm.addEventListener('submit', handleSemesterSubmit);
    if (classForm) classForm.addEventListener('submit', handleClassSubmit);
    if (attendanceForm) attendanceForm.addEventListener('submit', handleAttendanceSubmit);
    
    // Schedule management - add new class schedule time slots
    const addScheduleBtn = document.getElementById('addScheduleBtn');
    if (addScheduleBtn) addScheduleBtn.addEventListener('click', addScheduleItem);
    
    // Delete confirmation modal buttons
    const cancelDelete = document.getElementById('cancelDelete');
    const confirmDelete = document.getElementById('confirmDelete');
    if (cancelDelete) cancelDelete.addEventListener('click', () => hideModal('deleteClassModal'));
    if (confirmDelete) confirmDelete.addEventListener('click', handleClassDelete);
    
    // Modal close buttons (X buttons)
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';  // Find parent modal and hide it
        });
    });
    
    // Cancel buttons for various forms
    const cancelSemester = document.getElementById('cancelSemester');
    const cancelClass = document.getElementById('cancelClass');
    const cancelAttendance = document.getElementById('cancelAttendance');
    
    if (cancelSemester) cancelSemester.addEventListener('click', () => hideModal('semesterModal'));
    if (cancelClass) cancelClass.addEventListener('click', () => hideModal('classModal'));
    if (cancelAttendance) cancelAttendance.addEventListener('click', () => hideModal('attendanceModal'));
    
    // Close modal when clicking outside of modal content (on the overlay)
    window.addEventListener('click', function(event) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (event.target === modal) {  // Clicked directly on modal background
                modal.style.display = 'none';
            }
        });
    });
    
    console.log('Event listeners setup complete');
}

// Modal management functions

// Show a modal by its ID
function showModal(modalId) {
    console.log('Showing modal:', modalId);
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';  // Make modal visible
    } else {
        console.error('Modal not found:', modalId);
    }
}

// Hide a modal by its ID
function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';  // Hide modal
    }
}

// Show the semester selection modal
function showSemesterSelectModal() {
    console.log('Showing semester select modal');
    showModal('semesterSelectModal');
}

// Show the semester creation modal
function showSemesterModal() {
    console.log('Showing semester modal');
    hideModal('semesterSelectModal');  // Close selection modal first
    showModal('semesterModal');        // Show creation modal
}

// Show class modal for adding or editing a class
function showClassModal(semesterId, classId = null) {
    console.log('Showing class modal for semester:', semesterId, 'class:', classId);
    const currentSemesterId = document.getElementById('currentSemesterId');
    const editClassId = document.getElementById('editClassId');
    const classModalTitle = document.getElementById('classModalTitle');
    const classSubmitBtn = document.getElementById('classSubmitBtn');
    
    if (currentSemesterId) {
        currentSemesterId.value = semesterId;  // Store semester ID in hidden field
    }
    
    if (classId) {
        // Edit mode - populate form with existing class data
        classModalTitle.textContent = 'Edit Class';
        classSubmitBtn.textContent = 'Update Class';
        editClassId.value = classId;  // Store class ID being edited
        populateClassForm(classId);   // Fill form with class data
    } else {
        // Add mode - prepare empty form for new class
        classModalTitle.textContent = 'Add New Class';
        classSubmitBtn.textContent = 'Add Class';
        editClassId.value = '';       // Clear any previous class ID
        clearScheduleItems();         // Remove any existing schedule items
        addScheduleItem();            // Add one default schedule item
    }
    
    // Close the semester selection modal when opening class modal
    hideModal('semesterSelectModal');
    showModal('classModal');  // Show the class modal
}

// Show confirmation modal for deleting a class
function showDeleteClassModal(classId) {
    classToDelete = classId;  // Store which class to delete
    showModal('deleteClassModal');  // Show delete confirmation
}

// ============================================================================
// SEMESTER MANAGEMENT
// ============================================================================

// Load all semesters from the server
async function loadSemesters() {
    console.log('Loading semesters...');
    try {
        const response = await fetch('/api/semesters');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const semesters = await response.json();
        
        console.log('Semesters loaded:', semesters);
        displaySemesterList(semesters);  // Display in UI
        // Auto-select first semester if none is selected
        if (semesters.length > 0 && !currentSemester) {
            selectSemester(semesters[0]);
        }
    } catch (error) {
        console.error('Error loading semesters:', error);
        showError('Failed to load semesters: ' + error.message);
    }
}

// Display the list of semesters in the UI
function displaySemesterList(semesters) {
    const semesterList = document.getElementById('semesterList');
    if (!semesterList) {
        console.error('Semester list element not found');
        return;
    }
    
    if (semesters.length === 0) {
        semesterList.innerHTML = '<p class="no-data">No semesters found. Add your first semester!</p>';
        return;
    }
    
    // Create HTML for each semester item
    semesterList.innerHTML = semesters.map(semester => `
        <div class="semester-item ${currentSemester && currentSemester.id === semester.id ? 'active' : ''}" 
             onclick="selectSemester(${JSON.stringify(semester).replace(/"/g, '&quot;')})">
            <h4>${semester.name}</h4>
            <p>${formatDate(semester.start_date)} - ${formatDate(semester.end_date)}</p>
            <button class="btn-secondary" onclick="event.stopPropagation(); showClassModal(${semester.id})">
                Add Class
            </button>
        </div>
    `).join('');
}

// Select a semester as the current active semester
function selectSemester(semester) {
    console.log('Selecting semester:', semester);
    currentSemester = semester;
    hideModal('semesterSelectModal');  // Close selection modal
    updateCurrentSemesterDisplay();    // Update UI to show selected semester
    loadClasses();                     // Load classes for this semester
}

// Update the display to show the currently selected semester
function updateCurrentSemesterDisplay() {
    const content = document.getElementById('currentSemesterContent');
    if (!content) {
        console.error('Current semester content element not found');
        return;
    }
    
    if (!currentSemester) {
        content.innerHTML = '<p class="no-data">No active semester selected. Add a semester to get started.</p>';
        return;
    }
    
    // Create HTML for semester info display
    content.innerHTML = `
        <div class="semester-info">
            <h3>${currentSemester.name}</h3>
            <p>${formatDate(currentSemester.start_date)} - ${formatDate(currentSemester.end_date)}</p>
        </div>
        <div class="attendance-stats" id="semesterStats">
            <p>Loading statistics...</p>
        </div>
    `;
}

// Handle semester form submission (create new semester)
async function handleSemesterSubmit(e) {
    e.preventDefault();  // Prevent default form submission
    console.log('Handling semester form submission...');
    
    const formData = new FormData(e.target);
    const semesterData = {
        name: formData.get('name'),
        start_date: formData.get('start_date'),
        end_date: formData.get('end_date')
    };
    
    console.log('Submitting semester data:', semesterData);
    
    try {
        const response = await fetch('/api/semesters', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(semesterData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Semester created successfully');
            hideModal('semesterModal');  // Close modal
            loadSemesters();             // Reload semester list
            showSuccess('Semester created successfully!');
        } else {
            console.error('Failed to create semester:', result.error);
            showError(result.error || 'Failed to create semester');
        }
    } catch (error) {
        console.error('Error creating semester:', error);
        showError('Failed to create semester: ' + error.message);
    }
}

// ============================================================================
// CLASS MANAGEMENT
// ============================================================================

// Load classes for the current semester
async function loadClasses() {
    if (!currentSemester) {
        console.log('No current semester selected');
        return;
    }
    
    console.log('Loading classes for semester:', currentSemester.id);
    
    try {
        const response = await fetch(`/api/semesters/${currentSemester.id}/classes`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        classes = await response.json();  // Store classes in global variable
        
        console.log('Classes loaded:', classes);
        updateClassesList();        // Update class list display
        updateWeeklyCalendar();     // Update weekly schedule
        updateSemesterStats();      // Update attendance statistics
        updateAttendanceRecords();  // Update recent attendance records
    } catch (error) {
        console.error('Error loading classes:', error);
        showError('Failed to load classes: ' + error.message);
    }
}

// Update the class list display in the UI
function updateClassesList() {
    const classesList = document.getElementById('classesList');
    if (!classesList) {
        console.error('Classes list element not found');
        return;
    }
    
    if (!classes || classes.length === 0) {
        classesList.innerHTML = '<p class="no-data">No classes added yet. Add classes to your semester.</p>';
        return;
    }
    
    // Create HTML grid of class cards
    classesList.innerHTML = `
        <div class="classes-grid">
            ${classes.map(classObj => {
                const stats = classObj.attendance_stats || {};
                const presentCount = parseInt(stats.present_count) || 0;
                const absentCount = parseInt(stats.absent_count) || 0;
                const totalSessions = parseInt(stats.total_sessions) || 0;
                
                return `
                <div class="class-card" style="border-left-color: ${classObj.color || '#3b82f6'}">
                    <div class="class-card-header">
                        <div class="class-card-title">
                            <h3 class="class-code">${classObj.course_code}</h3>
                            <p class="class-name">${classObj.course_name}</p>
                        </div>
                        <div class="class-actions">
                            <button class="btn-edit" onclick="showClassModal(${currentSemester.id}, ${classObj.id})">
                                <i class="fa-solid fa-edit"></i>
                            </button>
                            <button class="btn-delete" onclick="showDeleteClassModal(${classObj.id})">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    <div class="class-details">
                        <div class="class-detail">
                            <i class="fa-solid fa-user"></i>
                            <span>${classObj.instructor || 'Not specified'}</span>
                        </div>
                        <div class="class-detail">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <span>${classObj.credits || 3} credits</span>
                        </div>
                    </div>
                    <div class="class-schedules">
                        ${(classObj.schedules || []).map(schedule => `
                            <span class="schedule-badge">
                                ${schedule.day_of_week} ${formatTime(schedule.start_time)}-${formatTime(schedule.end_time)}
                                ${schedule.room ? `(${schedule.room})` : ''}
                            </span>
                        `).join('')}
                    </div>
                    <div class="class-stats">
                        <div class="stat-item">
                            <div class="stat-number">${presentCount}</div>
                            <div class="stat-label-small">Present</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${absentCount}</div>
                            <div class="stat-label-small">Absent</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${totalSessions}</div>
                            <div class="stat-label-small">Total</div>
                        </div>
                    </div>
                </div>
                `;
            }).join('')}
        </div>
    `;
}

// Populate class form with existing data for editing
function populateClassForm(classId) {
    const classObj = classes.find(c => c.id === classId);
    if (!classObj) {
        console.error('Class not found for editing:', classId);
        return;
    }
    
    // Populate basic class info in form fields
    document.getElementById('courseCode').value = classObj.course_code;
    document.getElementById('courseName').value = classObj.course_name;
    document.getElementById('instructor').value = classObj.instructor || '';
    document.getElementById('credits').value = classObj.credits || 3;
    document.getElementById('classColor').value = classObj.color || '#3b82f6';
    
    // Populate schedule items
    clearScheduleItems();  // Remove any existing schedule items
    (classObj.schedules || []).forEach(schedule => {
        addScheduleItem();  // Add a new schedule item
        const lastItem = document.querySelector('.schedule-item:last-child');
        if (lastItem) {
            // Populate the schedule item with existing data
            lastItem.querySelector('[name="day"]').value = schedule.day_of_week;
            lastItem.querySelector('[name="start_time"]').value = schedule.start_time;
            lastItem.querySelector('[name="end_time"]').value = schedule.end_time;
            lastItem.querySelector('[name="room"]').value = schedule.room || '';
        }
    });
    
    // If no schedules exist, add one default schedule item
    if ((classObj.schedules || []).length === 0) {
        addScheduleItem();
    }
}

// Handle class form submission (create or update)
async function handleClassSubmit(e) {
    e.preventDefault();  // Prevent default form submission
    console.log('Handling class form submission...');
    
    const formData = new FormData(e.target);
    // Extract schedule data from all schedule items
    const scheduleItems = Array.from(document.querySelectorAll('.schedule-item')).map(item => {
        const daySelect = item.querySelector('[name="day"]');
        const startTimeInput = item.querySelector('[name="start_time"]');
        const endTimeInput = item.querySelector('[name="end_time"]');
        const roomInput = item.querySelector('[name="room"]');
        
        return {
            day: daySelect ? daySelect.value : '',
            start_time: startTimeInput ? startTimeInput.value : '',
            end_time: endTimeInput ? endTimeInput.value : '',
            room: roomInput ? roomInput.value : ''
        };
    }).filter(schedule => schedule.day && schedule.start_time && schedule.end_time);  // Filter out incomplete schedules
    
    const classId = document.getElementById('editClassId').value;
    const isEdit = !!classId;  // Determine if we're editing or creating
    
    // Prepare class data for API call
    const classData = {
        semester_id: parseInt(formData.get('semester_id')),
        course_code: formData.get('course_code'),
        course_name: formData.get('course_name'),
        instructor: formData.get('instructor'),
        credits: parseInt(formData.get('credits')) || 3,
        color: formData.get('color') || '#3b82f6',
        schedules: scheduleItems
    };
    
    console.log('Submitting class data:', classData, 'isEdit:', isEdit);
    
    try {
        const url = isEdit ? `/api/classes/${classId}` : '/api/classes';
        const method = isEdit ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(classData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Class ' + (isEdit ? 'updated' : 'created') + ' successfully');
            hideModal('classModal');  // Close the modal
            loadClasses();            // Reload classes to reflect changes
            showSuccess(`Class ${isEdit ? 'updated' : 'added'} successfully!`);
        } else {
            console.error('Failed to ' + (isEdit ? 'update' : 'add') + ' class:', result.error);
            showError(result.error || `Failed to ${isEdit ? 'update' : 'add'} class`);
        }
    } catch (error) {
        console.error('Error ' + (isEdit ? 'updating' : 'adding') + ' class:', error);
        showError(`Failed to ${isEdit ? 'update' : 'add'} class: ` + error.message);
    }
}

// Handle class deletion after confirmation
async function handleClassDelete() {
    if (!classToDelete) return;  // Exit if no class selected for deletion
    
    console.log('Deleting class:', classToDelete);
    
    try {
        const response = await fetch(`/api/classes/${classToDelete}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Class deleted successfully');
            hideModal('deleteClassModal');  // Close confirmation modal
            loadClasses();                   // Reload classes list
            showSuccess('Class deleted successfully!');
            classToDelete = null;           // Reset deletion tracking
        } else {
            console.error('Failed to delete class:', result.error);
            showError(result.error || 'Failed to delete class');
        }
    } catch (error) {
        console.error('Error deleting class:', error);
        showError('Failed to delete class: ' + error.message);
    }
}

// ============================================================================
// SCHEDULE MANAGEMENT
// ============================================================================

// Add a new schedule time slot to the class form
function addScheduleItem() {
    console.log('Adding schedule item');
    const scheduleItems = document.getElementById('scheduleItems');
    if (!scheduleItems) {
        console.error('Schedule items container not found');
        return;
    }
    
    const scheduleId = Date.now();  // Unique ID based on timestamp
    
    // Create HTML for new schedule item
    const scheduleHtml = `
        <div class="schedule-item" id="schedule-${scheduleId}">
            <div class="schedule-item-header">
                <h5>Class Schedule</h5>
                <button type="button" class="remove-schedule" onclick="removeScheduleItem(${scheduleId})">
                    Remove
                </button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Day of Week</label>
                    <select name="day" required>
                        <option value="">Select Day</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Start Time</label>
                    <input type="time" name="start_time" required>
                </div>
                <div class="form-group">
                    <label>End Time</label>
                    <input type="time" name="end_time" required>
                </div>
                <div class="form-group">
                    <label>Room (Optional)</label>
                    <input type="text" name="room" placeholder="e.g., Room 101">
                </div>
            </div>
        </div>
    `;
    
    scheduleItems.insertAdjacentHTML('beforeend', scheduleHtml);  // Add to end of container
}

// Remove a schedule time slot from the class form
function removeScheduleItem(scheduleId) {
    console.log('Removing schedule item:', scheduleId);
    const scheduleElement = document.getElementById(`schedule-${scheduleId}`);
    if (scheduleElement) {
        scheduleElement.remove();  // Remove from DOM
    }
}

// Clear all schedule time slots from the class form
function clearScheduleItems() {
    const scheduleItems = document.getElementById('scheduleItems');
    if (scheduleItems) {
        scheduleItems.innerHTML = '';  // Clear container
    }
}

// ============================================================================
// WEEKLY CALENDAR FUNCTIONALITY
// ============================================================================

// Calculate the start date of the week for a given date
function getWeekStart(date) {
    const day = date.getDay();  // 0 = Sunday, 1 = Monday, etc.
    // Calculate difference to Monday (if Sunday, go back 6 days; otherwise go to previous Monday)
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const weekStart = new Date(date);
    weekStart.setDate(diff);
    weekStart.setHours(0, 0, 0, 0);  // Set to start of day
    return weekStart;
}

// Update the week range display in the UI
function updateWeekDisplay() {
    const weekRangeElement = document.getElementById('currentWeekRange');
    if (!weekRangeElement) return;
    
    const weekEnd = new Date(currentWeekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);  // Add 6 days to get Sunday
    
    const startFormatted = formatDate(currentWeekStart.toISOString().split('T')[0]);
    const endFormatted = formatDate(weekEnd.toISOString().split('T')[0]);
    
    weekRangeElement.textContent = `${startFormatted} - ${endFormatted}`;
}

// Navigate to previous week in the calendar
function goToPreviousWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() - 7);  // Subtract 7 days
    updateWeekDisplay();    // Update week range display
    updateWeeklyCalendar(); // Refresh calendar view
}

// Navigate to next week in the calendar
function goToNextWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);  // Add 7 days
    updateWeekDisplay();    // Update week range display
    updateWeeklyCalendar(); // Refresh calendar view
}

// Update the weekly calendar view with class schedules
function updateWeeklyCalendar() {
    const calendar = document.getElementById('weeklyCalendar');
    if (!calendar) {
        console.error('Weekly calendar element not found');
        return;
    }
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    // Create HTML for each day column
    calendar.innerHTML = days.map(day => `
        <div class="day-column">
            <div class="day-header">${day}</div>
            <div class="day-classes" id="classes-${day}">
                ${renderClassSlotsForDay(day)}
            </div>
        </div>
    `).join('');
}

// Render class time slots for a specific day
function renderClassSlotsForDay(day) {
    if (!classes || classes.length === 0) {
        return '<p class="no-data">No classes scheduled</p>';
    }
    
    // Find all classes scheduled for this day
    const dayClasses = classes.flatMap(classObj => 
        (classObj.schedules || [])
            .filter(schedule => schedule.day_of_week === day)
            .map(schedule => ({ ...classObj, schedule }))
    );
    
    if (dayClasses.length === 0) {
        return '<p class="no-data">No classes scheduled</p>';
    }
    
    // Sort classes by start time (earliest first)
    dayClasses.sort((a, b) => a.schedule.start_time.localeCompare(b.schedule.start_time));
    
    // Create HTML for each class slot
    return dayClasses.map(classSchedule => `
        <div class="class-slot" 
             style="border-left-color: ${classSchedule.color || '#3b82f6'}"
             onclick="showAttendanceModal(${classSchedule.id}, '${classSchedule.schedule.day_of_week}')">
            <div class="class-time">
                ${formatTime(classSchedule.schedule.start_time)} - ${formatTime(classSchedule.schedule.end_time)}
            </div>
            <div class="class-name">${classSchedule.course_code}</div>
            <div class="class-room">${classSchedule.schedule.room || 'TBA'}</div>
        </div>
    `).join('');
}

// ============================================================================
// ATTENDANCE MANAGEMENT
// ============================================================================

// Show modal for recording attendance for a class
function showAttendanceModal(classId, dayOfWeek) {
    console.log('Showing attendance modal for class:', classId, 'on day:', dayOfWeek);
    
    const classObj = classes.find(c => c.id === classId);
    if (!classObj) {
        console.error('Class not found:', classId);
        return;
    }
    
    // Calculate the actual date for this class in the current week
    const dayIndex = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].indexOf(dayOfWeek);
    const classDate = new Date(currentWeekStart);
    classDate.setDate(currentWeekStart.getDate() + dayIndex);
    
    // Format date as YYYY-MM-DD for the form input
    const year = classDate.getFullYear();
    const month = String(classDate.getMonth() + 1).padStart(2, '0');
    const day = String(classDate.getDate()).padStart(2, '0');
    const classDateString = `${year}-${month}-${day}`;
    
    // Populate attendance form fields
    document.getElementById('attendanceClassId').value = classId;
    document.getElementById('attendanceDate').value = classDateString;
    document.getElementById('attendanceClassName').textContent = 
        `${classObj.course_code} - ${classObj.course_name}`;
    document.getElementById('attendanceDateDisplay').textContent = formatDate(classDateString);
    
    showModal('attendanceModal');  // Show the attendance modal
}

// Handle attendance form submission
async function handleAttendanceSubmit(e) {
    e.preventDefault();  // Prevent default form submission
    console.log('Handling attendance form submission...');
    
    const formData = new FormData(e.target);
    const attendanceData = {
        class_id: parseInt(document.getElementById('attendanceClassId').value),
        date: document.getElementById('attendanceDate').value,
        status: formData.get('status'),
        notes: formData.get('notes') || ''
    };
    
    console.log('Submitting attendance data:', attendanceData);
    
    try {
        const response = await fetch('/api/attendance', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(attendanceData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Attendance recorded successfully');
            hideModal('attendanceModal');  // Close modal
            updateAttendanceRecords();     // Refresh attendance records
            showSuccess('Attendance recorded successfully!');
        } else {
            console.error('Failed to record attendance:', result.error);
            showError(result.error || 'Failed to record attendance');
        }
    } catch (error) {
        console.error('Error recording attendance:', error);
        showError('Failed to record attendance: ' + error.message);
    }
}

// Update the recent attendance records display
async function updateAttendanceRecords() {
    if (!classes || classes.length === 0) {
        console.log('No classes to update attendance records for');
        return;
    }
    
    const recordsContainer = document.getElementById('attendanceRecords');
    if (!recordsContainer) {
        console.error('Attendance records container not found');
        return;
    }
    
    const allRecords = [];
    
    // Get attendance records for all classes
    for (const classObj of classes) {
        try {
            const response = await fetch(`/api/classes/${classObj.id}/attendance`);
            if (response.ok) {
                const records = await response.json();
                records.forEach(record => {
                    record.class_name = `${classObj.course_code} - ${classObj.course_name}`;
                    allRecords.push(record);
                });
            }
        } catch (error) {
            console.error('Error loading attendance for class', classObj.id, ':', error);
        }
    }
    
    // Sort by date (newest first) and take latest 5 records
    allRecords.sort((a, b) => new Date(b.date) - new Date(a.date));
    const recentRecords = allRecords.slice(0, 5);
    
    if (recentRecords.length === 0) {
        recordsContainer.innerHTML = '<p class="no-data">No attendance records yet. Mark attendance for your classes.</p>';
        return;
    }
    
    // Create HTML for recent attendance records
    recordsContainer.innerHTML = recentRecords.map(record => `
        <div class="attendance-record">
            <div>
                <strong>${record.class_name}</strong>
                <div>${formatDate(record.date)}</div>
                ${record.notes ? `<div><small>${record.notes}</small></div>` : ''}
            </div>
            <span class="record-status status-${record.status}">
                ${record.status.charAt(0).toUpperCase() + record.status.slice(1)}
            </span>
        </div>
    `).join('');
}

// Update semester-level attendance statistics
function updateSemesterStats() {
    const statsContainer = document.getElementById('semesterStats');
    if (!statsContainer) {
        console.error('Semester stats container not found');
        return;
    }
    
    if (!classes || classes.length === 0) {
        statsContainer.innerHTML = '<p class="no-data">No classes added yet</p>';
        return;
    }
    
    // Initialize counters for statistics
    let totalClasses = 0;
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalLate = 0;
    let totalExcused = 0;
    
    // Sum up statistics from all classes
    classes.forEach(classObj => {
        const stats = classObj.attendance_stats;
        if (stats) {
            totalClasses += parseInt(stats.total_sessions) || 0;
            totalPresent += parseInt(stats.present_count) || 0;
            totalAbsent += parseInt(stats.absent_count) || 0;
            totalLate += parseInt(stats.late_count) || 0;
            totalExcused += parseInt(stats.excused_count) || 0;
        }
    });
    
    const totalRecords = totalPresent + totalAbsent + totalLate + totalExcused;
    const attendanceRate = totalRecords > 0 ? Math.round((totalPresent / totalRecords) * 100) : 0;
    
    // Create HTML for statistics cards
    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${totalClasses}</div>
            <div class="stat-label">Total Classes Attended</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${attendanceRate}%</div>
            <div class="stat-label">Attendance Rate</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${totalPresent}</div>
            <div class="stat-label">Present</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${totalAbsent}</div>
            <div class="stat-label">Absent</div>
        </div>
    `;
}

// ============================================================================
// UTILITY FUNCTIONS (UPDATED WITH BETTER DATE HANDLING)
// ============================================================================

// Format date string to readable format with error handling
function formatDate(dateString) {
    if (!dateString) return 'No date';
    
    try {
        // Handle different date string formats from API
        let date;
        if (dateString.includes('T')) {
            // ISO format with time (e.g., "2024-01-15T00:00:00")
            date = new Date(dateString);
        } else {
            // Date-only format (e.g., "2024-01-15")
            date = new Date(dateString + 'T00:00:00');
        }
        
        // Check if date is valid
        if (isNaN(date.getTime())) {
            return 'Invalid Date';
        }
        
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return date.toLocaleDateString(undefined, options);  // Format like "Jan 15, 2024"
    } catch (error) {
        console.error('Error formatting date:', dateString, error);
        return 'Invalid Date';
    }
}

// Format time string to 12-hour format with AM/PM
function formatTime(timeString) {
    if (!timeString) return 'No time';
    
    try {
        // Handle different time formats from API
        let timeParts;
        if (timeString.includes(':')) {
            // Already in HH:MM or HH:MM:SS format
            timeParts = timeString.split(':');
        } else {
            // Assume it's in HHMMSS format
            timeParts = [timeString.substring(0, 2), timeString.substring(2, 4)];
        }
        
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);
        
        if (isNaN(hours) || isNaN(minutes)) {
            return 'Invalid Time';
        }
        
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours % 12 || 12;  // Convert 0, 13-23 to 12, 1-11
        const displayMinutes = minutes.toString().padStart(2, '0');
        
        return `${displayHours}:${displayMinutes} ${period}`;  // Format like "2:30 PM"
    } catch (error) {
        console.error('Error formatting time:', timeString, error);
        return 'Invalid Time';
    }
}

// Initialize the weekly calendar (alias for updateWeeklyCalendar)
function loadWeeklyCalendar() {
    updateWeeklyCalendar();
}