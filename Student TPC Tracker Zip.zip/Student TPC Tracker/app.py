from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import mysql.connector
import hashlib
from datetime import datetime, date, timedelta
import os
from dotenv import load_dotenv
# Load environment variables from .env file
load_dotenv()

# Create Flask app instance with static and template folders
app = Flask(__name__, static_folder='static', template_folder='templates')
# Set secret key for session security - get from environment or use default
app.secret_key = os.getenv('SECRET_KEY') or 'secret-key'

def hash_password(password):
    """Hash password using SHA-256 for secure storage"""
    return hashlib.sha256(password.encode()).hexdigest()

def get_db_connection():
    """Create and return database connection using environment variables"""
    try:
        conn = mysql.connector.connect(
            host=os.getenv('MYSQL_HOST', 'localhost'),
            user=os.getenv('MYSQL_USER', 'root'),
            password=os.getenv('MYSQL_PASSWORD', 'hp-2024aleah'),
            database=os.getenv('MYSQL_DB', 'tracksmart'),
            autocommit=True  # Automatically commit transactions
        )
        return conn
    except mysql.connector.Error as e:
        print(f"Database connection error: {e}")
        return None

def init_db():
    """Initialize database with all required tables"""
    try:
        conn = get_db_connection()
        if not conn:
            # Try to connect without database first to create it
            conn = mysql.connector.connect(host='localhost', user='root', password='hp-2024aleah')
        
        cursor = conn.cursor()
        # Create database if it doesn't exist
        cursor.execute("CREATE DATABASE IF NOT EXISTS tracksmart")
        cursor.execute("USE tracksmart")  # Switch to tracksmart database
        
        # Define all table creation SQL statements
        tables = [
            # Users table for storing user accounts
            """CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""",
            # Password reset tokens for secure password recovery
            """CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                token VARCHAR(255) NOT NULL UNIQUE, expires_at TIMESTAMP NOT NULL,
                used BOOLEAN DEFAULT FALSE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)""",
            # Tasks table for user tasks/to-do items
            """CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL, description TEXT, deadline DATE,
                status ENUM('pending', 'completed') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id))""",
            # Semesters table for academic semesters
            """CREATE TABLE IF NOT EXISTS semesters (
                id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                name VARCHAR(255) NOT NULL, start_date DATE NOT NULL, end_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id))""",
            # Classes table for course information
            """CREATE TABLE IF NOT EXISTS classes (
                id INT AUTO_INCREMENT PRIMARY KEY, semester_id INT NOT NULL,
                course_code VARCHAR(50) NOT NULL, course_name VARCHAR(255) NOT NULL,
                instructor VARCHAR(255), credits INT DEFAULT 3, color VARCHAR(7) DEFAULT '#3b82f6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE)""",
            # Class schedules for weekly class timings
            """CREATE TABLE IF NOT EXISTS class_schedules (
                id INT AUTO_INCREMENT PRIMARY KEY, class_id INT NOT NULL,
                day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
                start_time TIME NOT NULL, end_time TIME NOT NULL, room VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE)""",
            # Attendance records for tracking class attendance
            """CREATE TABLE IF NOT EXISTS attendance_records (
                id INT AUTO_INCREMENT PRIMARY KEY, class_id INT NOT NULL, date DATE NOT NULL,
                status ENUM('present','absent','late','excused') NOT NULL, notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE)"""
        ]
        
        # Execute all table creation statements
        for table_sql in tables:
            cursor.execute(table_sql)
        
        conn.commit()  # Save all changes to database
        cursor.close()
        conn.close()
        return True
    except mysql.connector.Error as e:
        print(f"Error initializing database: {e}")
        return False

# Initialize database when app starts
init_db()

# Route for home page
@app.route('/') 
@app.route('/home')
def home():
    """Home page showing upcoming tasks for logged-in users"""
    upcoming_tasks = []
    if 'user' in session:  # Check if user is logged in
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            # Get upcoming incomplete tasks for the user
            cursor.execute("SELECT * FROM tasks WHERE user_id = %s AND deadline >= CURDATE() AND status != 'completed' ORDER BY deadline ASC LIMIT 5", (session['user']['id'],))
            upcoming_tasks = cursor.fetchall()
            cursor.close()
            conn.close()
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
    return render_template('homepage.html', upcoming_tasks=upcoming_tasks)

@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')

@app.route('/contact')
def contact():
    """Contact page"""
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login handling"""
    if 'user' in session:  # If already logged in, redirect to home
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        # Get form data and sanitize
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember_me = request.form.get('remember_me') == 'true'  # Remember me checkbox
        
        if not email or not password:
            flash('Please enter both email and password', 'error')
            return render_template('login1.html')
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            # Check if user exists with provided credentials
            cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, hash_password(password)))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if user:
                # Create user session
                session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
                session.permanent = remember_me  # Set session permanence based on remember me
                flash('Login successful!', 'success')
                return redirect(url_for('home'))
            else:
                flash('Invalid email or password', 'error')
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
    
    return render_template('login1.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration handling"""
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Validate input
        if not username or not email or not password:
            flash('All fields are required', 'error')
            return redirect(url_for('login', show='register'))
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return redirect(url_for('login', show='register'))
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            # Check if user already exists
            cursor.execute("SELECT id FROM users WHERE email = %s OR username = %s", (email, username))
            if cursor.fetchone():
                flash('User already exists with this email or username', 'error')
                return redirect(url_for('login', show='register'))
            
            # Create new user
            cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, hash_password(password)))
            conn.commit()
            cursor.close()
            conn.close()
            
            # Get the newly created user data
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            # Create session for new user
            session['user'] = {'id': user['id'], 'username': user['username'], 'email': user['email']}
            flash('Registration successful! Welcome to TrackSmart!', 'success')
            return redirect(url_for('home'))
            
        except mysql.connector.Error as e:
            flash('Registration failed. Please try again.', 'error')
    
    return redirect(url_for('login', show='register'))

@app.route('/logout')
def logout():
    """Logout user by clearing session"""
    session.pop('user', None)  # Remove user from session
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Handle password reset requests"""
    if 'user' in session:
        return redirect(url_for('home'))
    
    if request.method == 'GET':
        return render_template('forgot_password.html')
    
    email = request.form.get('email')
    if not email:
        flash('Please enter your email address', 'error')
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, username FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        
        if user:
            # Generate secure token and expiration
            token = secrets.token_urlsafe(32)
            expires_at = datetime.now() + timedelta(hours=1)
            # Store reset token in database
            cursor.execute("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (%s, %s, %s)", (user['id'], token, expires_at))
            conn.commit()
            reset_url = url_for('reset_password', token=token, _external=True)
            print(f"Password reset URL for {email}: {reset_url}")  # In production, send email instead
        
        cursor.close()
        conn.close()
        flash('If an account with that email exists, a password reset link has been sent.', 'info')
        return redirect(url_for('login'))
    except mysql.connector.Error as e:
        flash('An error occurred. Please try again.', 'error')
        return redirect(url_for('login'))

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Handle password reset with token"""
    if request.method == 'GET':
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            # Verify token is valid and not expired
            cursor.execute("SELECT u.id, u.username FROM password_reset_tokens prt JOIN users u ON prt.user_id = u.id WHERE prt.token = %s AND prt.expires_at > NOW() AND prt.used = FALSE", (token,))
            token_data = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if not token_data:
                flash('Invalid or expired reset token.', 'error')
                return redirect(url_for('login'))
            
            return render_template('reset_password.html', token=token, username=token_data['username'])
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
            return redirect(url_for('login'))
    
    else:  # POST request - actually reset password
        new_password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not new_password or not confirm_password:
            flash('Please fill in all fields', 'error')
            return render_template('reset_password.html', token=token)
        
        if new_password != confirm_password or len(new_password) < 6:
            flash('Passwords do not match or are too short', 'error')
            return render_template('reset_password.html', token=token)
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            # Verify token is still valid
            cursor.execute("SELECT user_id FROM password_reset_tokens WHERE token = %s AND expires_at > NOW() AND used = FALSE", (token,))
            token_data = cursor.fetchone()
            
            if not token_data:
                flash('Invalid or expired reset token.', 'error')
                return redirect(url_for('login'))
            
            # Update user password and mark token as used
            cursor.execute("UPDATE users SET password = %s WHERE id = %s", (hash_password(new_password), token_data['user_id']))
            cursor.execute("UPDATE password_reset_tokens SET used = TRUE WHERE token = %s", (token,))
            conn.commit()
            cursor.close()
            conn.close()
            
            flash('Your password has been reset successfully!', 'success')
            return redirect(url_for('login'))
        except mysql.connector.Error as e:
            flash('An error occurred. Please try again.', 'error')
            return render_template('reset_password.html', token=token)

@app.route('/tasks')
def tasks():
    """Tasks management page"""
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('task.html')

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    """API endpoint to get all tasks for logged-in user"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tasks WHERE user_id = %s ORDER BY deadline ASC", (session['user']['id'],))
        tasks = cursor.fetchall()
        
        # Convert date objects to strings for JSON serialization
        for task in tasks:
            if task['deadline']:
                task['deadline'] = task['deadline'].isoformat()
            task['description'] = task['description'] or ''  # Ensure description is not None
        
        cursor.close()
        conn.close()
        return jsonify(tasks)
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks', methods=['POST'])
def create_task():
    """API endpoint to create new task"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()  # Get JSON data from request
    if not data or not data.get('title'):
        return jsonify({'error': 'Title is required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Insert new task into database
        cursor.execute("INSERT INTO tasks (user_id, title, description, deadline) VALUES (%s, %s, %s, %s)", (session['user']['id'], data.get('title'), data.get('description', ''), data.get('deadline')))
        conn.commit()
        task_id = cursor.lastrowid  # Get ID of newly created task
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'task_id': task_id})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """API endpoint to update existing task"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Verify task belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        if not cursor.fetchone():
            return jsonify({'error': 'Task not found'}), 404
        
        # Update task details
        cursor.execute("UPDATE tasks SET title = %s, description = %s, deadline = %s WHERE id = %s", (data.get('title'), data.get('description'), data.get('deadline'), task_id))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>/status', methods=['PUT'])
def update_task_status(task_id):
    """API endpoint to update task status only"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    status = data.get('status')
    
    if status not in ['pending', 'completed']:
        return jsonify({'error': 'Invalid status'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Verify task belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        if not cursor.fetchone():
            return jsonify({'error': 'Task not found'}), 404
        
        # Update only the status field
        cursor.execute("UPDATE tasks SET status = %s WHERE id = %s", (status, task_id))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """API endpoint to delete task"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Verify task belongs to current user
        cursor.execute("SELECT id FROM tasks WHERE id = %s AND user_id = %s", (task_id, session['user']['id']))
        if not cursor.fetchone():
            return jsonify({'error': 'Task not found'}), 404
        
        # Delete the task
        cursor.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/attendance')
def attendance():
    """Attendance management page"""
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('attendance.html')

@app.route('/api/semesters', methods=['GET'])
def get_semesters():
    """API endpoint to get all semesters for logged-in user"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM semesters WHERE user_id = %s ORDER BY start_date DESC", (session['user']['id'],))
        semesters = cursor.fetchall()
        
        # Convert date objects to strings for JSON
        for semester in semesters:
            semester['start_date'] = semester['start_date'].isoformat()
            semester['end_date'] = semester['end_date'].isoformat()
        
        cursor.close()
        conn.close()
        return jsonify(semesters)
    except mysql.connector.Error as e:
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/semesters', methods=['POST'])
def create_semester():
    """API endpoint to create new semester"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data or not all(key in data for key in ['name', 'start_date', 'end_date']):
        return jsonify({'error': 'Name, start date, and end date are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Insert new semester
        cursor.execute("INSERT INTO semesters (user_id, name, start_date, end_date) VALUES (%s, %s, %s, %s)", (session['user']['id'], data['name'], data['start_date'], data['end_date']))
        conn.commit()
        semester_id = cursor.lastrowid
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'semester_id': semester_id})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes', methods=['POST'])
def create_class():
    """API endpoint to create new class with schedules"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data or not all(key in data for key in ['semester_id', 'course_code', 'course_name']):
        return jsonify({'error': 'Semester, course code, and course name are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Insert new class
        cursor.execute("INSERT INTO classes (semester_id, course_code, course_name, instructor, credits, color) VALUES (%s, %s, %s, %s, %s, %s)", (data['semester_id'], data['course_code'], data['course_name'], data.get('instructor', ''), data.get('credits', 3), data.get('color', '#3b82f6')))
        class_id = cursor.lastrowid
        
        # Insert class schedules
        for schedule in data.get('schedules', []):
            cursor.execute("INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)", (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', '')))
        
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True, 'class_id': class_id})
    except mysql.connector.Error as e:
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/semesters/<int:semester_id>/classes', methods=['GET'])
def get_classes(semester_id):
    """API endpoint to get all classes for a specific semester with schedules and attendance stats"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get classes for semester
        cursor.execute("""
            SELECT c.*, s.name as semester_name 
            FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.semester_id = %s AND s.user_id = %s
        """, (semester_id, session['user']['id']))
        classes = cursor.fetchall()
        
        # Get schedules for each class
        for class_obj in classes:
            cursor.execute("""
                SELECT * FROM class_schedules 
                WHERE class_id = %s 
                ORDER BY 
                    FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
                    start_time
            """, (class_obj['id'],))
            schedules = cursor.fetchall()
            
            # Convert time objects to strings for JSON
            for schedule in schedules:
                schedule['start_time'] = str(schedule['start_time'])
                schedule['end_time'] = str(schedule['end_time'])
            
            class_obj['schedules'] = schedules
            
            # Get attendance statistics for the class
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_sessions,
                    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_count,
                    SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
                    SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_count,
                    SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) as excused_count
                FROM attendance_records 
                WHERE class_id = %s
            """, (class_obj['id'],))
            stats = cursor.fetchone()
            
            # Ensure all counts are integers (not None)
            if stats:
                class_obj['attendance_stats'] = {
                    'total_sessions': stats['total_sessions'] or 0,
                    'present_count': stats['present_count'] or 0,
                    'absent_count': stats['absent_count'] or 0,
                    'late_count': stats['late_count'] or 0,
                    'excused_count': stats['excused_count'] or 0
                }
            else:
                class_obj['attendance_stats'] = {
                    'total_sessions': 0,
                    'present_count': 0,
                    'absent_count': 0,
                    'late_count': 0,
                    'excused_count': 0
                }
        
        cursor.close()
        conn.close()
        
        return jsonify(classes)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/classes/<int:class_id>', methods=['PUT'])
def update_class(class_id):
    """API endpoint to update class information and schedules"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    course_code = data.get('course_code')
    course_name = data.get('course_name')
    instructor = data.get('instructor', '')
    credits = data.get('credits', 3)
    color = data.get('color', '#3b82f6')
    schedules = data.get('schedules', [])
    
    if not course_code or not course_name:
        return jsonify({'error': 'Course code and course name are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Update class information
        cursor.execute("""
            UPDATE classes 
            SET course_code = %s, course_name = %s, instructor = %s, credits = %s, color = %s
            WHERE id = %s
        """, (course_code, course_name, instructor, credits, color, class_id))
        
        # Delete existing schedules
        cursor.execute("DELETE FROM class_schedules WHERE class_id = %s", (class_id,))
        
        # Insert new schedules
        for schedule in schedules:
            cursor.execute(
                "INSERT INTO class_schedules (class_id, day_of_week, start_time, end_time, room) VALUES (%s, %s, %s, %s, %s)",
                (class_id, schedule['day'], schedule['start_time'], schedule['end_time'], schedule.get('room', ''))
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes/<int:class_id>', methods=['DELETE'])
def delete_class(class_id):
    """API endpoint to delete class and its related data"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Delete class (cascade will delete schedules and attendance records)
        cursor.execute("DELETE FROM classes WHERE id = %s", (class_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/attendance', methods=['POST'])
def record_attendance():
    """API endpoint to record or update attendance for a class on specific date"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    class_id = data.get('class_id')
    date = data.get('date')
    status = data.get('status')
    notes = data.get('notes', '')
    
    if not class_id or not date or not status:
        return jsonify({'error': 'Class ID, date, and status are required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if attendance already exists for this class and date
        cursor.execute(
            "SELECT id FROM attendance_records WHERE class_id = %s AND date = %s",
            (class_id, date)
        )
        existing_record = cursor.fetchone()
        
        if existing_record:
            # Update existing record
            cursor.execute(
                "UPDATE attendance_records SET status = %s, notes = %s WHERE id = %s",
                (status, notes, existing_record[0])
            )
        else:
            # Insert new record
            cursor.execute(
                "INSERT INTO attendance_records (class_id, date, status, notes) VALUES (%s, %s, %s, %s)",
                (class_id, date, status, notes)
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/classes/<int:class_id>/attendance', methods=['GET'])
def get_class_attendance(class_id):
    """API endpoint to get all attendance records for a specific class"""
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Verify user owns this class
        cursor.execute("""
            SELECT c.id FROM classes c 
            JOIN semesters s ON c.semester_id = s.id 
            WHERE c.id = %s AND s.user_id = %s
        """, (class_id, session['user']['id']))
        
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'error': 'Class not found'}), 404
        
        # Get attendance records
        cursor.execute("""
            SELECT * FROM attendance_records 
            WHERE class_id = %s 
            ORDER BY date DESC
        """, (class_id,))
        
        attendance_records = cursor.fetchall()
        
        # Convert date objects to strings for JSON
        for record in attendance_records:
            record['date'] = record['date'].isoformat()
        
        cursor.close()
        conn.close()
        
        return jsonify(attendance_records)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

if __name__ == '__main__':
    app.run(debug=True)  # Run Flask app in debug mode