// Navigation toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (navbarToggle && navbarMenu) {
        navbarToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
            navbarToggle.classList.toggle('active');
        });
    }

    // Login/Register form switching
    const wrapper = document.querySelector('.wrapper');
    const loginLink = document.querySelector('.login-link');
    const registerLink = document.querySelector('.register-link');
    const iconClose = document.querySelector('.icon-close');

    if (registerLink) {
        registerLink.addEventListener('click', (e) => {
            e.preventDefault();
            wrapper.classList.add('active');
        });
    }

    if (loginLink) {
        loginLink.addEventListener('click', (e) => {
            e.preventDefault();
            wrapper.classList.remove('active');
        });
    }

    if (iconClose) {
        iconClose.addEventListener('click', () => {
            wrapper.classList.remove('active-popup');
        });
    }

    // Tasks functionality
    if (document.getElementById('taskList')) {
        initializeTasks();
    }

    // Auto-hide flash messages after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.display = 'none';
        });
    }, 5000);
});

// Tasks Management
let tasks = [];
let currentTaskId = null;

// Load tasks when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadTasks();
    setupEventListeners();
});

function setupEventListeners() {
    // Modal controls
    document.getElementById('addTaskBtn').addEventListener('click', openCreateModal);
    document.getElementById('closeModal').addEventListener('click', closeModal);
    document.getElementById('cancelTask').addEventListener('click', closeModal);
    document.getElementById('taskForm').addEventListener('submit', saveTask);
    
    // Delete modal controls
    document.getElementById('cancelDelete').addEventListener('click', closeDeleteModal);
    document.getElementById('confirmDelete').addEventListener('click', confirmDelete);
    
    // Filter tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            filterTasks(this.dataset.filter);
        });
    });
}

async function loadTasks() {
    try {
        const response = await fetch('/api/tasks');
        if (response.ok) {
            tasks = await response.json();
            renderTasks();
        } else {
            console.error('Failed to load tasks');
            showError('Failed to load tasks');
        }
    } catch (error) {
        console.error('Error loading tasks:', error);
        showError('Error loading tasks');
    }
}

function renderTasks() {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';

    if (tasks.length === 0) {
        taskList.innerHTML = '<p class="no-tasks">No tasks found. Create your first task!</p>';
        return;
    }

    tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        taskList.appendChild(taskElement);
    });
}

function createTaskElement(task) {
    const taskDiv = document.createElement('div');
    taskDiv.className = `task-item ${task.status}`;
    taskDiv.dataset.taskId = task.id;
    
    const formattedDate = task.deadline ? new Date(task.deadline).toLocaleDateString() : 'No deadline';
    const isCompleted = task.status === 'completed';
    
    taskDiv.innerHTML = `
        <div class="task-content">
            <div class="task-header">
                <label class="checkbox-container">
                    <input type="checkbox" ${isCompleted ? 'checked' : ''} onchange="toggleTask(${task.id})">
                    <span class="checkmark"></span>
                </label>
                <div class="task-title ${isCompleted ? 'completed' : ''}">${escapeHtml(task.title)}</div>
                <div class="task-actions">
                    <button class="icon-btn edit-btn" onclick="openEditModal(${task.id})" title="Edit task">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="icon-btn delete-btn" onclick="openDeleteModal(${task.id})" title="Delete task">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            ${task.description ? `<div class="task-description">${escapeHtml(task.description)}</div>` : ''}
            <div class="task-footer">
                <span class="task-deadline ${isOverdue(task.deadline) && !isCompleted ? 'overdue' : ''}">
                    <i class="fas fa-calendar"></i> ${formattedDate}
                </span>
            </div>
        </div>
    `;
    
    return taskDiv;
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function isOverdue(deadline) {
    if (!deadline) return false;
    return new Date(deadline) < new Date();
}

async function toggleTask(taskId) {
    try {
        const response = await fetch(`/api/tasks/${taskId}/toggle`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            loadTasks(); // Reload tasks to reflect changes
        } else {
            console.error('Failed to toggle task status');
            showError('Failed to update task status');
        }
    } catch (error) {
        console.error('Error toggling task:', error);
        showError('Error updating task');
    }
}

function openCreateModal() {
    document.getElementById('modalTitle').textContent = 'Create Task';
    document.getElementById('taskForm').reset();
    document.getElementById('taskId').value = '';
    currentTaskId = null;
    document.getElementById('taskModal').style.display = 'block';
}

function openEditModal(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        document.getElementById('modalTitle').textContent = 'Edit Task';
        document.getElementById('taskId').value = task.id;
        document.getElementById('taskName').value = task.title;
        document.getElementById('taskDescript').value = task.description || '';
        document.getElementById('taskDate').value = task.deadline || '';
        currentTaskId = taskId;
        document.getElementById('taskModal').style.display = 'block';
    }
}

function closeModal() {
    document.getElementById('taskModal').style.display = 'none';
}

async function saveTask(e) {
    e.preventDefault();
    
    const taskData = {
        title: document.getElementById('taskName').value,
        description: document.getElementById('taskDescript').value,
        deadline: document.getElementById('taskDate').value
    };
    
    const url = currentTaskId ? `/api/tasks/${currentTaskId}` : '/api/tasks';
    const method = currentTaskId ? 'PUT' : 'POST';
    
    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        });
        
        if (response.ok) {
            closeModal();
            loadTasks();
            showSuccess('Task saved successfully!');
        } else {
            console.error('Failed to save task');
            showError('Failed to save task');
        }
    } catch (error) {
        console.error('Error saving task:', error);
        showError('Error saving task');
    }
}

function openDeleteModal(taskId) {
    currentTaskId = taskId;
    document.getElementById('deleteModal').style.display = 'block';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
}

async function confirmDelete() {
    if (!currentTaskId) return;
    
    try {
        const response = await fetch(`/api/tasks/${currentTaskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            closeDeleteModal();
            loadTasks();
            showSuccess('Task deleted successfully!');
        } else {
            console.error('Failed to delete task');
            showError('Failed to delete task');
        }
    } catch (error) {
        console.error('Error deleting task:', error);
        showError('Error deleting task');
    }
}

function filterTasks(filter) {
    const taskItems = document.querySelectorAll('.task-item');
    
    taskItems.forEach(item => {
        switch (filter) {
            case 'pending':
                item.style.display = item.classList.contains('pending') ? 'block' : 'none';
                break;
            case 'completed':
                item.style.display = item.classList.contains('completed') ? 'block' : 'none';
                break;
            default: // 'all'
                item.style.display = 'block';
        }
    });
}

// Utility functions for user feedbac
function showSuccess(message) {
    console.log('Success:', message);
}

function showError(message) {
    console.error('Error:', message);
    alert(message); // Fallback to alert for now
}
