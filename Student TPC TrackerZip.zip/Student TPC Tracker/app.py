from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import mysql.connector
import hashlib
from datetime import datetime, date
import json

app = Flask(__name__)
app.secret_key = 'NYAYANNA'

# Database configuration
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='hp-2024aleah',
            database='tracksmart'
        )
        return conn
    except mysql.connector.Error as e:
        print(f"Database connection error: {e}")
        return None

# Initialize database
def init_db():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='hp-2024aleah'
        )
        cursor = conn.cursor()
        
        # Create database if it doesn't exist
        cursor.execute("CREATE DATABASE IF NOT EXISTS tracksmart")
        cursor.execute("USE tracksmart")
        
        # Create users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create tasks table - MATCHING YOUR EXISTING SCHEMA
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                idtasks INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                deadline DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
        print("Database initialized successfully")
        
    except mysql.connector.Error as e:
        print(f"Error initializing database: {e}")

# Hash password function
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Initialize database when app starts
init_db()

# Routes
@app.route('/')
@app.route('/home')
def home():
    upcoming_tasks = []
    if 'user' in session:
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""
                SELECT * FROM tasks 
                WHERE user_id = %s AND deadline >= CURDATE()
                ORDER BY deadline ASC 
                LIMIT 5
            """, (session['user']['id'],))
            upcoming_tasks = cursor.fetchall()
            cursor.close()
            conn.close()
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
    
    return render_template('homepage.html', upcoming_tasks=upcoming_tasks)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Check if user exists with this email and password
            cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", 
                          (email, hash_password(password)))
            user = cursor.fetchone()
            
            cursor.close()
            conn.close()
            
            if user:
                session['user'] = {
                    'id': user['id'],
                    'username': user['username'],
                    'email': user['email']
                }
                flash('Login successful!', 'success')
                return redirect(url_for('home'))
            else:
                flash('Invalid email or password', 'error')
                
        except mysql.connector.Error as e:
            flash('Database error occurred. Please try again.', 'error')
            print(f"Database error: {e}")
    
    return render_template('login1.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Basic validation
        if not username or not email or not password:
            flash('All fields are required', 'error')
            return redirect(url_for('login', show='register'))
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long', 'error')
            return redirect(url_for('login', show='register'))
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Check if user already exists
            cursor.execute("SELECT id FROM users WHERE email = %s OR username = %s", (email, username))
            existing_user = cursor.fetchone()
            
            if existing_user:
                flash('User already exists with this email or username', 'error')
                cursor.close()
                conn.close()
                return redirect(url_for('login', show='register'))
            
            # Insert new user
            cursor.execute(
                "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                (username, email, hash_password(password))
            )
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # Get the new user data for session
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
            
            # Set session
            session['user'] = {
                'id': user['id'],
                'username': user['username'],
                'email': user['email']
            }
            
            flash('Registration successful! Welcome to TrackSmart!', 'success')
            return redirect(url_for('home'))
            
        except mysql.connector.Error as e:
            flash('Registration failed. Please try again.', 'error')
            print(f"Database error: {e}")
            return redirect(url_for('login', show='register'))
    
    # If GET request, show the registration form
    return redirect(url_for('login', show='register'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

# Tasks Routes
@app.route('/tasks')
def tasks():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('task.html')

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get all tasks for user - SIMPLIFIED without status filter
        cursor.execute("SELECT * FROM tasks WHERE user_id = %s ORDER BY deadline ASC", (user_id,))
        tasks = cursor.fetchall()
        
        # Convert date objects to strings and add status field for frontend compatibility
        for task in tasks:
            if task['deadline']:
                task['deadline'] = task['deadline'].isoformat()
            task['created_at'] = task['created_at'].isoformat()
            # Add status field for frontend compatibility (all tasks are "pending" in this version)
            task['status'] = 'pending'
            # Map idtasks to id for frontend compatibility
            task['id'] = task['idtasks']
        
        cursor.close()
        conn.close()
        
        return jsonify(tasks)
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/tasks', methods=['POST'])
def create_task():
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    title = data.get('title')
    deadline = data.get('deadline')
    user_id = session['user']['id']
    
    if not title:
        return jsonify({'error': 'Title is required'}), 400
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        print(f"Creating task: {title}, {deadline} for user {user_id}")
        
        # Insert task - SIMPLIFIED without description and status
        cursor.execute(
            "INSERT INTO tasks (user_id, title, deadline) VALUES (%s, %s, %s)",
            (user_id, title, deadline)
        )
        
        conn.commit()
        task_id = cursor.lastrowid
        
        cursor.close()
        conn.close()
        
        print(f"Task created successfully with ID: {task_id}")
        return jsonify({'success': True, 'task_id': task_id})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': f'Database error: {str(e)}'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if task belongs to user
        cursor.execute("SELECT idtasks FROM tasks WHERE idtasks = %s AND user_id = %s", (task_id, user_id))
        task = cursor.fetchone()
        
        if not task:
            cursor.close()
            conn.close()
            return jsonify({'error': 'Task not found'}), 404
        
        # Update task - SIMPLIFIED (only title and deadline)
        cursor.execute(
            "UPDATE tasks SET title = %s, deadline = %s WHERE idtasks = %s",
            (data.get('title'), data.get('deadline'), task_id)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    if 'user' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user']['id']
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if task belongs to user
        cursor.execute("SELECT idtasks FROM tasks WHERE idtasks = %s AND user_id = %s", (task_id, user_id))
        task = cursor.fetchone()
        
        if not task:
            cursor.close()
            conn.close()
            return jsonify({'error': 'Task not found'}), 404
        
        # Delete task
        cursor.execute("DELETE FROM tasks WHERE idtasks = %s", (task_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({'success': True})
        
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({'error': 'Database error'}), 500

# Attendance Routes
@app.route('/attendance')
def attendance():
    if 'user' not in session:
        flash('Please log in first.', 'warning')
        return redirect(url_for('login'))
    return render_template('attendance.html')


if __name__ == '__main__':
    app.run(debug=True)