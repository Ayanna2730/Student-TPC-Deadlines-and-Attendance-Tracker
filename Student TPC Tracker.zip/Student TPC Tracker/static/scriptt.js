// Main JavaScript for common functionality
// Add this at the start of your scriptt.js file
document.addEventListener('DOMContentLoaded', function() {
    // Consolidated hamburger menu toggle functionality
    const menuBtn = document.getElementById('hamburger-toggle');  // Use the new ID for precision
    const navMenu = document.querySelector('.navbar-menu');
    
    if (menuBtn && navMenu) {
        menuBtn.addEventListener('click', function(event) {
            event.preventDefault();  // Prevent any default behavior
            event.stopPropagation();  // Stop bubbling
            console.log('Hamburger button clicked');  // For debugging
            menuBtn.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    } else {
        console.error('Hamburger button or menu not found');  // Log if elements are missing
    }
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (navMenu.classList.contains('active') && 
            !event.target.closest('.navbar-toggle') && 
            !event.target.closest('.navbar-menu')) {
            navMenu.classList.remove('active');
            menuBtn.classList.remove('active');
        }
    });
    // Close menu when pressing Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            menuBtn.classList.remove('active');
        }
      });

    // Auto-hide flash messages after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.display = 'none';
        });
    }, 5000);

    // Initialize tasks functionality if on tasks page
    if (document.getElementById('taskList')) {
        initializeTasks();
    }

    // Initialize auth functionality if on login page
    if (document.getElementById('loginForm')) {
        initializeAuth();
    }
});

// Authentication form handling
document.addEventListener('DOMContentLoaded', function() {
    // Fix form switching functionality
    const wrapper = document.querySelector('.wrapper');
    const registerLink = document.querySelector('.register-link');
    const loginLink = document.querySelector('.login-link');
    
    console.log('Form switching elements:', { wrapper, registerLink, loginLink });

    if (registerLink && loginLink && wrapper) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Switching to register form');
            wrapper.classList.add('active');
        });

        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Switching to login form');
            wrapper.classList.remove('active');
        });
    } else {
        console.error('Form switching elements not found');
    }

    // Check URL parameters for form display
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('show') === 'register') {
        console.log('Showing register form from URL parameter');
        if (wrapper) {
            wrapper.classList.add('active');
        }
    }

    // Mobile menu toggle
    const navbarToggle = document.querySelector('.navbar-toggle');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (navbarToggle && navbarMenu) {
        navbarToggle.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
            navbarToggle.classList.toggle('active');
        });
    }

    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll('.navbar-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navbarToggle && navbarMenu) {
                navbarToggle.classList.remove('active');
                navbarMenu.classList.remove('active');
            }
        });
    });

    // Auto-hide flash messages after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.display = 'none';
        });
    }, 5000);

    // Initialize tasks functionality if on tasks page
    if (document.getElementById('taskList')) {
        initializeTasks();
    }

    // Initialize attendance functionality if on attendance page
    if (document.getElementById('attendanceContainer')) {
        initializeAttendance();
    }
});

// Task management functionality
let tasks = [];
let currentTaskId = null;

function initializeTasks() {
    loadTasks();
    setupTaskEventListeners();
}

function setupTaskEventListeners() {
    // Modal controls
    const addTaskBtn = document.getElementById('addTaskBtn');
    const closeModalBtn = document.getElementById('closeModal');
    const cancelTaskBtn = document.getElementById('cancelTask');
    const taskForm = document.getElementById('taskForm');
    
    // Delete modal controls
    const cancelDeleteBtn = document.getElementById('cancelDelete');
    const confirmDeleteBtn = document.getElementById('confirmDelete');
    
    // Add event listeners
    if (addTaskBtn) addTaskBtn.addEventListener('click', openCreateModal);
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeTaskModal);
    if (cancelTaskBtn) cancelTaskBtn.addEventListener('click', closeTaskModal);
    if (taskForm) taskForm.addEventListener('submit', saveTask);
    
    if (cancelDeleteBtn) cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    if (confirmDeleteBtn) confirmDeleteBtn.addEventListener('click', confirmDeleteTask);
    
    // Filter tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            filterTasks(this.dataset.filter);
        });
    });

    // Close modal when clicking outside
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
}

async function loadTasks() {
    try {
        console.log('Loading tasks...');
        const response = await fetch('/api/tasks');
        
        if (response.status === 401) {
            console.log('User not authenticated, redirecting to login...');
            showError('Please log in to view tasks');
            window.location.href = '/login';
            return;
        }
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Failed to load tasks:', response.status, errorText);
            showError('Failed to load tasks. Please try again.');
            return;
        }
        
        const tasksData = await response.json();
        
        // Handle case where API returns error object
        if (tasksData.error) {
            console.error('API returned error:', tasksData.error);
            showError('Failed to load tasks: ' + tasksData.error);
            return;
        }
        
        tasks = tasksData;
        console.log('Tasks loaded successfully:', tasks);
        
        // Ensure all tasks have the required fields with defaults
        tasks = tasks.map(task => ({
            id: task.id,
            title: task.title || '',
            description: task.description || '',
            deadline: task.deadline || null,
            status: task.status || 'pending',
            created_at: task.created_at
        }));
        
        renderTasks();
        updateTaskStats();
        
    } catch (error) {
        console.error('Error loading tasks:', error);
        showError('Error loading tasks. Please check your connection.');
    }
}

function renderTasks() {
    const taskList = document.getElementById('taskList');
    if (!taskList) return;
    
    taskList.innerHTML = '';

    if (tasks.length === 0) {
        taskList.innerHTML = '<div class="no-tasks">No tasks found. Create your first task!</div>';
        return;
    }

    tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        taskList.appendChild(taskElement);
    });
}

function createTaskElement(task) {
    const taskDiv = document.createElement('div');
    
    // Determine task classes
    const isCompleted = task.status === 'completed';
    const isOverdue = isTaskOverdue(task);
    
    let taskClasses = ['task-card'];
    if (isCompleted) taskClasses.push('completed');
    if (isOverdue) taskClasses.push('overdue');
    
    taskDiv.className = taskClasses.join(' ');
    taskDiv.dataset.taskId = task.id;
    
    const formattedDate = task.deadline ? new Date(task.deadline).toLocaleDateString() : 'No deadline';
    
    taskDiv.innerHTML = `
        <div class="task-header">
            <div class="task-title ${isCompleted ? 'completed' : ''}">${escapeHtml(task.title)}</div>
            <div class="task-actions">
                <button class="icon-btn edit-btn" onclick="openEditModal(${task.id})" title="Edit task">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="icon-btn delete-btn" onclick="openDeleteModal(${task.id})" title="Delete task">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        ${task.description ? `<div class="task-description ${isCompleted ? 'completed' : ''}">${escapeHtml(task.description)}</div>` : ''}
        <div class="task-footer">
            <span class="task-deadline ${isOverdue && !isCompleted ? 'overdue' : ''}">
                <i class="fas fa-calendar"></i> ${formattedDate}
            </span>
        </div>
        <div class="task-status">
            <label class="checkbox-container">
                <input type="checkbox" ${isCompleted ? 'checked' : ''} onchange="toggleTaskStatus(${task.id})">
                <span class="checkmark"></span>
                <span class="status-text">${isCompleted ? 'Completed' : 'Mark as Complete'}</span>
            </label>
        </div>
    `;
    
    return taskDiv;
}

function isTaskOverdue(task) {
    if (!task.deadline || task.status === 'completed') return false;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const taskDate = new Date(task.deadline);
    taskDate.setHours(0, 0, 0, 0);
    
    return taskDate < today;
}

function updateTaskStats() {
    const totalTasks = tasks.length;
    const pendingTasks = tasks.filter(task => task.status === 'pending').length;
    const completedTasks = tasks.filter(task => task.status === 'completed').length;
    const overdueTasks = tasks.filter(task => isTaskOverdue(task)).length;
    
    const totalTasksEl = document.getElementById('totalTasks');
    const pendingTasksEl = document.getElementById('pendingTasks');
    const completedTasksEl = document.getElementById('completedTasks');
    const overdueTasksEl = document.getElementById('overdueTasks');
    
    if (totalTasksEl) totalTasksEl.textContent = totalTasks;
    if (pendingTasksEl) pendingTasksEl.textContent = pendingTasks;
    if (completedTasksEl) completedTasksEl.textContent = completedTasks;
    if (overdueTasksEl) overdueTasksEl.textContent = overdueTasks;
}

function filterTasks(filter) {
    const taskCards = document.querySelectorAll('.task-card');
    
    taskCards.forEach(card => {
        const taskId = parseInt(card.dataset.taskId);
        const task = tasks.find(t => t.id === taskId);
        
        if (!task) return;
        
        let shouldShow = true;
        
        switch (filter) {
            case 'pending':
                shouldShow = task.status === 'pending';
                break;
            case 'completed':
                shouldShow = task.status === 'completed';
                break;
            case 'overdue':
                shouldShow = isTaskOverdue(task);
                break;
            default: // 'all'
                shouldShow = true;
        }
        
        card.style.display = shouldShow ? 'block' : 'none';
    });
}

function openCreateModal() {
    const modal = document.getElementById('taskModal');
    const modalTitle = document.getElementById('modalTitle');
    const taskForm = document.getElementById('taskForm');
    
    if (modal && modalTitle && taskForm) {
        modalTitle.textContent = 'Create Task';
        taskForm.reset();
        document.getElementById('taskId').value = '';
        
        // Set default date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('taskDate').value = today;
        
        currentTaskId = null;
        modal.style.display = 'block';
    }
}

function openEditModal(taskId) {
    const task = tasks.find(t => t.id === taskId);
    const modal = document.getElementById('taskModal');
    const modalTitle = document.getElementById('modalTitle');
    
    if (task && modal && modalTitle) {
        modalTitle.textContent = 'Edit Task';
        document.getElementById('taskId').value = task.id;
        document.getElementById('taskName').value = task.title || '';
        document.getElementById('taskDescript').value = task.description || '';
        document.getElementById('taskDate').value = task.deadline ? task.deadline.split('T')[0] : '';
        currentTaskId = taskId;
        modal.style.display = 'block';
    }
}

function openDeleteModal(taskId) {
    currentTaskId = taskId;
    const modal = document.getElementById('deleteModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

async function saveTask(e) {
    e.preventDefault();
    
    const title = document.getElementById('taskName').value;
    const description = document.getElementById('taskDescript').value;
    const deadline = document.getElementById('taskDate').value;
    
    if (!title.trim()) {
        showError('Task title is required');
        return;
    }
    
    const taskData = {
        title: title.trim(),
        description: description.trim(),
        deadline: deadline
    };
    
    const url = currentTaskId ? `/api/tasks/${currentTaskId}` : '/api/tasks';
    const method = currentTaskId ? 'PUT' : 'POST';
    
    try {
        console.log('Saving task:', taskData, 'URL:', url, 'Method:', method);
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(taskData)
        });
        
        if (response.ok) {
            closeTaskModal();
            await loadTasks(); // Wait for reload to complete
            showSuccess(currentTaskId ? 'Task updated successfully!' : 'Task created successfully!');
        } else {
            const errorData = await response.json();
            console.error('Failed to save task:', errorData);
            showError('Failed to save task: ' + (errorData.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error saving task:', error);
        showError('Error saving task. Please try again.');
    }
}

async function toggleTaskStatus(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
        console.error('Task not found:', taskId);
        showError('Task not found');
        return;
    }
    
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    
    try {
        console.log('Updating task status:', taskId, 'to:', newStatus);
        const response = await fetch(`/api/tasks/${taskId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: newStatus
            })
        });
        
        if (response.ok) {
            // Update local task state immediately for better UX
            task.status = newStatus;
            renderTasks();
            updateTaskStats();
            showSuccess(`Task marked as ${newStatus}!`);
        } else {
            const errorData = await response.json();
            console.error('Failed to update task status:', errorData);
            showError('Failed to update task status: ' + (errorData.error || 'Unknown error'));
            // Reload tasks to ensure sync with server
            await loadTasks();
        }
    } catch (error) {
        console.error('Error updating task status:', error);
        showError('Error updating task status. Please try again.');
        // Reload tasks to ensure sync with server
        await loadTasks();
    }
}

async function confirmDeleteTask() {
    if (!currentTaskId) {
        console.error('No task ID selected for deletion');
        return;
    }
    
    try {
        console.log('Deleting task:', currentTaskId);
        const response = await fetch(`/api/tasks/${currentTaskId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            closeDeleteModal();
            await loadTasks();
            showSuccess('Task deleted successfully!');
        } else {
            const errorData = await response.json();
            console.error('Failed to delete task:', errorData);
            showError('Failed to delete task: ' + (errorData.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error deleting task:', error);
        showError('Error deleting task. Please try again.');
    }
}

function closeTaskModal() {
    const modal = document.getElementById('taskModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Utility functions
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function showSuccess(message) {
    // Create a toast notification
    const toast = document.createElement('div');
    toast.className = 'toast success';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 3000);
}

function showError(message) {
    // Create a toast notification
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 3000);
}

// Inject toast styles only once
if (!document.querySelector('#toast-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'toast-styles';
    styleSheet.textContent = `
    .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 4px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .toast.success {
        background-color: #28a745;
    }

    .toast.error {
        background-color: #dc3545;
    }

    .toast-content {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }`;
    document.head.appendChild(styleSheet);
}

// ============================================================================
// ATTENDANCE FUNCTIONALITY - REPLACED SECTION
// ============================================================================

let currentSemester = null;
let currentWeekStart = null;
let classes = [];
let classToDelete = null;

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing attendance system...');
    initializeAttendance();
    setupEventListeners();
    loadSemesters();
});

function initializeAttendance() {
    // Set current week to today
    const today = new Date();
    currentWeekStart = getWeekStart(today);
    updateWeekDisplay();
    loadWeeklyCalendar();
}

function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    // Modal controls
    const addSemesterBtn = document.getElementById('addSemesterBtn');
    if (addSemesterBtn) {
        addSemesterBtn.addEventListener('click', showSemesterSelectModal);
    } else {
        console.error('Add semester button not found');
    }
    
    const addNewSemesterBtn = document.getElementById('addNewSemesterBtn');
    if (addNewSemesterBtn) {
        addNewSemesterBtn.addEventListener('click', showSemesterModal);
    }
    
    // Week navigation
    const prevWeekBtn = document.getElementById('prevWeek');
    const nextWeekBtn = document.getElementById('nextWeek');
    if (prevWeekBtn) prevWeekBtn.addEventListener('click', goToPreviousWeek);
    if (nextWeekBtn) nextWeekBtn.addEventListener('click', goToNextWeek);
    
    // Form submissions
    const semesterForm = document.getElementById('semesterForm');
    const classForm = document.getElementById('classForm');
    const attendanceForm = document.getElementById('attendanceForm');
    
    if (semesterForm) semesterForm.addEventListener('submit', handleSemesterSubmit);
    if (classForm) classForm.addEventListener('submit', handleClassSubmit);
    if (attendanceForm) attendanceForm.addEventListener('submit', handleAttendanceSubmit);
    
    // Schedule management
    const addScheduleBtn = document.getElementById('addScheduleBtn');
    if (addScheduleBtn) addScheduleBtn.addEventListener('click', addScheduleItem);
    
    // Delete confirmation
    const cancelDelete = document.getElementById('cancelDelete');
    const confirmDelete = document.getElementById('confirmDelete');
    if (cancelDelete) cancelDelete.addEventListener('click', () => hideModal('deleteClassModal'));
    if (confirmDelete) confirmDelete.addEventListener('click', handleClassDelete);
    
    // Modal close buttons
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Cancel buttons
    const cancelSemester = document.getElementById('cancelSemester');
    const cancelClass = document.getElementById('cancelClass');
    const cancelAttendance = document.getElementById('cancelAttendance');
    
    if (cancelSemester) cancelSemester.addEventListener('click', () => hideModal('semesterModal'));
    if (cancelClass) cancelClass.addEventListener('click', () => hideModal('classModal'));
    if (cancelAttendance) cancelAttendance.addEventListener('click', () => hideModal('attendanceModal'));
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
    
    console.log('Event listeners setup complete');
}

// Modal management
function showModal(modalId) {
    console.log('Showing modal:', modalId);
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    } else {
        console.error('Modal not found:', modalId);
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

function showSemesterSelectModal() {
    console.log('Showing semester select modal');
    showModal('semesterSelectModal');
}

function showSemesterModal() {
    console.log('Showing semester modal');
    hideModal('semesterSelectModal');
    showModal('semesterModal');
}

function showClassModal(semesterId, classId = null) {
    console.log('Showing class modal for semester:', semesterId, 'class:', classId);
    const currentSemesterId = document.getElementById('currentSemesterId');
    const editClassId = document.getElementById('editClassId');
    const classModalTitle = document.getElementById('classModalTitle');
    const classSubmitBtn = document.getElementById('classSubmitBtn');
    
    if (currentSemesterId) {
        currentSemesterId.value = semesterId;
    }
    
    if (classId) {
        // Edit mode
        classModalTitle.textContent = 'Edit Class';
        classSubmitBtn.textContent = 'Update Class';
        editClassId.value = classId;
        populateClassForm(classId);
    } else {
        // Add mode
        classModalTitle.textContent = 'Add New Class';
        classSubmitBtn.textContent = 'Add Class';
        editClassId.value = '';
        clearScheduleItems();
        addScheduleItem(); // Add one default schedule item
    }
    
    // Close the semester selection modal when opening class modal
    hideModal('semesterSelectModal');
    showModal('classModal');
}

function showDeleteClassModal(classId) {
    classToDelete = classId;
    showModal('deleteClassModal');
}

// Semester management
async function loadSemesters() {
    console.log('Loading semesters...');
    try {
        const response = await fetch('/api/semesters');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const semesters = await response.json();
        
        console.log('Semesters loaded:', semesters);
        displaySemesterList(semesters);
        if (semesters.length > 0 && !currentSemester) {
            selectSemester(semesters[0]);
        }
    } catch (error) {
        console.error('Error loading semesters:', error);
        showError('Failed to load semesters: ' + error.message);
    }
}

function displaySemesterList(semesters) {
    const semesterList = document.getElementById('semesterList');
    if (!semesterList) {
        console.error('Semester list element not found');
        return;
    }
    
    if (semesters.length === 0) {
        semesterList.innerHTML = '<p class="no-data">No semesters found. Add your first semester!</p>';
        return;
    }
    
    semesterList.innerHTML = semesters.map(semester => `
        <div class="semester-item ${currentSemester && currentSemester.id === semester.id ? 'active' : ''}" 
             onclick="selectSemester(${JSON.stringify(semester).replace(/"/g, '&quot;')})">
            <h4>${semester.name}</h4>
            <p>${formatDate(semester.start_date)} - ${formatDate(semester.end_date)}</p>
            <button class="btn-secondary" onclick="event.stopPropagation(); showClassModal(${semester.id})">
                Add Class
            </button>
        </div>
    `).join('');
}

function selectSemester(semester) {
    console.log('Selecting semester:', semester);
    currentSemester = semester;
    hideModal('semesterSelectModal');
    updateCurrentSemesterDisplay();
    loadClasses();
}

function updateCurrentSemesterDisplay() {
    const content = document.getElementById('currentSemesterContent');
    if (!content) {
        console.error('Current semester content element not found');
        return;
    }
    
    if (!currentSemester) {
        content.innerHTML = '<p class="no-data">No active semester selected. Add a semester to get started.</p>';
        return;
    }
    
    content.innerHTML = `
        <div class="semester-info">
            <h3>${currentSemester.name}</h3>
            <p>${formatDate(currentSemester.start_date)} - ${formatDate(currentSemester.end_date)}</p>
        </div>
        <div class="attendance-stats" id="semesterStats">
            <p>Loading statistics...</p>
        </div>
    `;
}

async function handleSemesterSubmit(e) {
    e.preventDefault();
    console.log('Handling semester form submission...');
    
    const formData = new FormData(e.target);
    const semesterData = {
        name: formData.get('name'),
        start_date: formData.get('start_date'),
        end_date: formData.get('end_date')
    };
    
    console.log('Submitting semester data:', semesterData);
    
    try {
        const response = await fetch('/api/semesters', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(semesterData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Semester created successfully');
            hideModal('semesterModal');
            loadSemesters();
            showSuccess('Semester created successfully!');
        } else {
            console.error('Failed to create semester:', result.error);
            showError(result.error || 'Failed to create semester');
        }
    } catch (error) {
        console.error('Error creating semester:', error);
        showError('Failed to create semester: ' + error.message);
    }
}

// Class management
async function loadClasses() {
    if (!currentSemester) {
        console.log('No current semester selected');
        return;
    }
    
    console.log('Loading classes for semester:', currentSemester.id);
    
    try {
        const response = await fetch(`/api/semesters/${currentSemester.id}/classes`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        classes = await response.json();
        
        console.log('Classes loaded:', classes);
        updateClassesList();
        updateWeeklyCalendar();
        updateSemesterStats();
        updateAttendanceRecords();
    } catch (error) {
        console.error('Error loading classes:', error);
        showError('Failed to load classes: ' + error.message);
    }
}

function updateClassesList() {
    const classesList = document.getElementById('classesList');
    if (!classesList) {
        console.error('Classes list element not found');
        return;
    }
    
    if (!classes || classes.length === 0) {
        classesList.innerHTML = '<p class="no-data">No classes added yet. Add classes to your semester.</p>';
        return;
    }
    
    classesList.innerHTML = `
        <div class="classes-grid">
            ${classes.map(classObj => {
                const stats = classObj.attendance_stats || {};
                const presentCount = parseInt(stats.present_count) || 0;
                const absentCount = parseInt(stats.absent_count) || 0;
                const totalSessions = parseInt(stats.total_sessions) || 0;
                
                return `
                <div class="class-card" style="border-left-color: ${classObj.color || '#3b82f6'}">
                    <div class="class-card-header">
                        <div class="class-card-title">
                            <h3 class="class-code">${classObj.course_code}</h3>
                            <p class="class-name">${classObj.course_name}</p>
                        </div>
                        <div class="class-actions">
                            <button class="btn-edit" onclick="showClassModal(${currentSemester.id}, ${classObj.id})">
                                <i class="fa-solid fa-edit"></i>
                            </button>
                            <button class="btn-delete" onclick="showDeleteClassModal(${classObj.id})">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    <div class="class-details">
                        <div class="class-detail">
                            <i class="fa-solid fa-user"></i>
                            <span>${classObj.instructor || 'Not specified'}</span>
                        </div>
                        <div class="class-detail">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <span>${classObj.credits || 3} credits</span>
                        </div>
                    </div>
                    <div class="class-schedules">
                        ${(classObj.schedules || []).map(schedule => `
                            <span class="schedule-badge">
                                ${schedule.day_of_week} ${formatTime(schedule.start_time)}-${formatTime(schedule.end_time)}
                                ${schedule.room ? `(${schedule.room})` : ''}
                            </span>
                        `).join('')}
                    </div>
                    <div class="class-stats">
                        <div class="stat-item">
                            <div class="stat-number">${presentCount}</div>
                            <div class="stat-label-small">Present</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${absentCount}</div>
                            <div class="stat-label-small">Absent</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${totalSessions}</div>
                            <div class="stat-label-small">Total</div>
                        </div>
                    </div>
                </div>
                `;
            }).join('')}
        </div>
    `;
}

function populateClassForm(classId) {
    const classObj = classes.find(c => c.id === classId);
    if (!classObj) {
        console.error('Class not found for editing:', classId);
        return;
    }
    
    // Populate basic class info
    document.getElementById('courseCode').value = classObj.course_code;
    document.getElementById('courseName').value = classObj.course_name;
    document.getElementById('instructor').value = classObj.instructor || '';
    document.getElementById('credits').value = classObj.credits || 3;
    document.getElementById('classColor').value = classObj.color || '#3b82f6';
    
    // Populate schedules
    clearScheduleItems();
    (classObj.schedules || []).forEach(schedule => {
        addScheduleItem();
        const lastItem = document.querySelector('.schedule-item:last-child');
        if (lastItem) {
            lastItem.querySelector('[name="day"]').value = schedule.day_of_week;
            lastItem.querySelector('[name="start_time"]').value = schedule.start_time;
            lastItem.querySelector('[name="end_time"]').value = schedule.end_time;
            lastItem.querySelector('[name="room"]').value = schedule.room || '';
        }
    });
    
    // If no schedules, add one default
    if ((classObj.schedules || []).length === 0) {
        addScheduleItem();
    }
}

async function handleClassSubmit(e) {
    e.preventDefault();
    console.log('Handling class form submission...');
    
    const formData = new FormData(e.target);
    const scheduleItems = Array.from(document.querySelectorAll('.schedule-item')).map(item => {
        const daySelect = item.querySelector('[name="day"]');
        const startTimeInput = item.querySelector('[name="start_time"]');
        const endTimeInput = item.querySelector('[name="end_time"]');
        const roomInput = item.querySelector('[name="room"]');
        
        return {
            day: daySelect ? daySelect.value : '',
            start_time: startTimeInput ? startTimeInput.value : '',
            end_time: endTimeInput ? endTimeInput.value : '',
            room: roomInput ? roomInput.value : ''
        };
    }).filter(schedule => schedule.day && schedule.start_time && schedule.end_time);
    
    const classId = document.getElementById('editClassId').value;
    const isEdit = !!classId;
    
    const classData = {
        semester_id: parseInt(formData.get('semester_id')),
        course_code: formData.get('course_code'),
        course_name: formData.get('course_name'),
        instructor: formData.get('instructor'),
        credits: parseInt(formData.get('credits')) || 3,
        color: formData.get('color') || '#3b82f6',
        schedules: scheduleItems
    };
    
    console.log('Submitting class data:', classData, 'isEdit:', isEdit);
    
    try {
        const url = isEdit ? `/api/classes/${classId}` : '/api/classes';
        const method = isEdit ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(classData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Class ' + (isEdit ? 'updated' : 'created') + ' successfully');
            hideModal('classModal');
            loadClasses();
            showSuccess(`Class ${isEdit ? 'updated' : 'added'} successfully!`);
        } else {
            console.error('Failed to ' + (isEdit ? 'update' : 'add') + ' class:', result.error);
            showError(result.error || `Failed to ${isEdit ? 'update' : 'add'} class`);
        }
    } catch (error) {
        console.error('Error ' + (isEdit ? 'updating' : 'adding') + ' class:', error);
        showError(`Failed to ${isEdit ? 'update' : 'add'} class: ` + error.message);
    }
}

async function handleClassDelete() {
    if (!classToDelete) return;
    
    console.log('Deleting class:', classToDelete);
    
    try {
        const response = await fetch(`/api/classes/${classToDelete}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Class deleted successfully');
            hideModal('deleteClassModal');
            loadClasses();
            showSuccess('Class deleted successfully!');
            classToDelete = null;
        } else {
            console.error('Failed to delete class:', result.error);
            showError(result.error || 'Failed to delete class');
        }
    } catch (error) {
        console.error('Error deleting class:', error);
        showError('Failed to delete class: ' + error.message);
    }
}

// Schedule management
function addScheduleItem() {
    console.log('Adding schedule item');
    const scheduleItems = document.getElementById('scheduleItems');
    if (!scheduleItems) {
        console.error('Schedule items container not found');
        return;
    }
    
    const scheduleId = Date.now();
    
    const scheduleHtml = `
        <div class="schedule-item" id="schedule-${scheduleId}">
            <div class="schedule-item-header">
                <h5>Class Schedule</h5>
                <button type="button" class="remove-schedule" onclick="removeScheduleItem(${scheduleId})">
                    Remove
                </button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Day of Week</label>
                    <select name="day" required>
                        <option value="">Select Day</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Start Time</label>
                    <input type="time" name="start_time" required>
                </div>
                <div class="form-group">
                    <label>End Time</label>
                    <input type="time" name="end_time" required>
                </div>
                <div class="form-group">
                    <label>Room (Optional)</label>
                    <input type="text" name="room" placeholder="e.g., Room 101">
                </div>
            </div>
        </div>
    `;
    
    scheduleItems.insertAdjacentHTML('beforeend', scheduleHtml);
}

function removeScheduleItem(scheduleId) {
    console.log('Removing schedule item:', scheduleId);
    const scheduleElement = document.getElementById(`schedule-${scheduleId}`);
    if (scheduleElement) {
        scheduleElement.remove();
    }
}

function clearScheduleItems() {
    const scheduleItems = document.getElementById('scheduleItems');
    if (scheduleItems) {
        scheduleItems.innerHTML = '';
    }
}

// Weekly Calendar
function getWeekStart(date) {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const weekStart = new Date(date);
    weekStart.setDate(diff);
    weekStart.setHours(0, 0, 0, 0);
    return weekStart;
}

function updateWeekDisplay() {
    const weekRangeElement = document.getElementById('currentWeekRange');
    if (!weekRangeElement) return;
    
    const weekEnd = new Date(currentWeekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    
    const startFormatted = formatDate(currentWeekStart.toISOString().split('T')[0]);
    const endFormatted = formatDate(weekEnd.toISOString().split('T')[0]);
    
    weekRangeElement.textContent = `${startFormatted} - ${endFormatted}`;
}

function goToPreviousWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() - 7);
    updateWeekDisplay();
    updateWeeklyCalendar();
}

function goToNextWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    updateWeekDisplay();
    updateWeeklyCalendar();
}

function updateWeeklyCalendar() {
    const calendar = document.getElementById('weeklyCalendar');
    if (!calendar) {
        console.error('Weekly calendar element not found');
        return;
    }
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    calendar.innerHTML = days.map(day => `
        <div class="day-column">
            <div class="day-header">${day}</div>
            <div class="day-classes" id="classes-${day}">
                ${renderClassSlotsForDay(day)}
            </div>
        </div>
    `).join('');
}

function renderClassSlotsForDay(day) {
    if (!classes || classes.length === 0) {
        return '<p class="no-data">No classes scheduled</p>';
    }
    
    const dayClasses = classes.flatMap(classObj => 
        (classObj.schedules || [])
            .filter(schedule => schedule.day_of_week === day)
            .map(schedule => ({ ...classObj, schedule }))
    );
    
    if (dayClasses.length === 0) {
        return '<p class="no-data">No classes scheduled</p>';
    }
    
    // Sort by start time
    dayClasses.sort((a, b) => a.schedule.start_time.localeCompare(b.schedule.start_time));
    
    return dayClasses.map(classSchedule => `
        <div class="class-slot" 
             style="border-left-color: ${classSchedule.color || '#3b82f6'}"
             onclick="showAttendanceModal(${classSchedule.id}, '${classSchedule.schedule.day_of_week}')">
            <div class="class-time">
                ${formatTime(classSchedule.schedule.start_time)} - ${formatTime(classSchedule.schedule.end_time)}
            </div>
            <div class="class-name">${classSchedule.course_code}</div>
            <div class="class-room">${classSchedule.schedule.room || 'TBA'}</div>
        </div>
    `).join('');
}

// Attendance management
function showAttendanceModal(classId, dayOfWeek) {
    console.log('Showing attendance modal for class:', classId, 'on day:', dayOfWeek);
    
    const classObj = classes.find(c => c.id === classId);
    if (!classObj) {
        console.error('Class not found:', classId);
        return;
    }
    
    // Get the date for this class in the current week
    const dayIndex = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].indexOf(dayOfWeek);
    const classDate = new Date(currentWeekStart);
    classDate.setDate(currentWeekStart.getDate() + dayIndex);
    
    // Format date as YYYY-MM-DD for the form
    const year = classDate.getFullYear();
    const month = String(classDate.getMonth() + 1).padStart(2, '0');
    const day = String(classDate.getDate()).padStart(2, '0');
    const classDateString = `${year}-${month}-${day}`;
    
    document.getElementById('attendanceClassId').value = classId;
    document.getElementById('attendanceDate').value = classDateString;
    document.getElementById('attendanceClassName').textContent = 
        `${classObj.course_code} - ${classObj.course_name}`;
    document.getElementById('attendanceDateDisplay').textContent = formatDate(classDateString);
    
    showModal('attendanceModal');
}

async function handleAttendanceSubmit(e) {
    e.preventDefault();
    console.log('Handling attendance form submission...');
    
    const formData = new FormData(e.target);
    const attendanceData = {
        class_id: parseInt(document.getElementById('attendanceClassId').value),
        date: document.getElementById('attendanceDate').value,
        status: formData.get('status'),
        notes: formData.get('notes') || ''
    };
    
    console.log('Submitting attendance data:', attendanceData);
    
    try {
        const response = await fetch('/api/attendance', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(attendanceData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('Attendance recorded successfully');
            hideModal('attendanceModal');
            updateAttendanceRecords();
            showSuccess('Attendance recorded successfully!');
        } else {
            console.error('Failed to record attendance:', result.error);
            showError(result.error || 'Failed to record attendance');
        }
    } catch (error) {
        console.error('Error recording attendance:', error);
        showError('Failed to record attendance: ' + error.message);
    }
}

async function updateAttendanceRecords() {
    if (!classes || classes.length === 0) {
        console.log('No classes to update attendance records for');
        return;
    }
    
    const recordsContainer = document.getElementById('attendanceRecords');
    if (!recordsContainer) {
        console.error('Attendance records container not found');
        return;
    }
    
    const allRecords = [];
    
    // Get attendance for all classes
    for (const classObj of classes) {
        try {
            const response = await fetch(`/api/classes/${classObj.id}/attendance`);
            if (response.ok) {
                const records = await response.json();
                records.forEach(record => {
                    record.class_name = `${classObj.course_code} - ${classObj.course_name}`;
                    allRecords.push(record);
                });
            }
        } catch (error) {
            console.error('Error loading attendance for class', classObj.id, ':', error);
        }
    }
    
    // Sort by date (newest first) and take latest 5
    allRecords.sort((a, b) => new Date(b.date) - new Date(a.date));
    const recentRecords = allRecords.slice(0, 5);
    
    if (recentRecords.length === 0) {
        recordsContainer.innerHTML = '<p class="no-data">No attendance records yet. Mark attendance for your classes.</p>';
        return;
    }
    
    recordsContainer.innerHTML = recentRecords.map(record => `
        <div class="attendance-record">
            <div>
                <strong>${record.class_name}</strong>
                <div>${formatDate(record.date)}</div>
                ${record.notes ? `<div><small>${record.notes}</small></div>` : ''}
            </div>
            <span class="record-status status-${record.status}">
                ${record.status.charAt(0).toUpperCase() + record.status.slice(1)}
            </span>
        </div>
    `).join('');
}

function updateSemesterStats() {
    const statsContainer = document.getElementById('semesterStats');
    if (!statsContainer) {
        console.error('Semester stats container not found');
        return;
    }
    
    if (!classes || classes.length === 0) {
        statsContainer.innerHTML = '<p class="no-data">No classes added yet</p>';
        return;
    }
    
    let totalClasses = 0;
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalLate = 0;
    let totalExcused = 0;
    
    classes.forEach(classObj => {
        const stats = classObj.attendance_stats;
        if (stats) {
            totalClasses += parseInt(stats.total_sessions) || 0;
            totalPresent += parseInt(stats.present_count) || 0;
            totalAbsent += parseInt(stats.absent_count) || 0;
            totalLate += parseInt(stats.late_count) || 0;
            totalExcused += parseInt(stats.excused_count) || 0;
        }
    });
    
    const totalRecords = totalPresent + totalAbsent + totalLate + totalExcused;
    const attendanceRate = totalRecords > 0 ? Math.round((totalPresent / totalRecords) * 100) : 0;
    
    statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${totalClasses}</div>
            <div class="stat-label">Total Classes</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${attendanceRate}%</div>
            <div class="stat-label">Attendance Rate</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${totalPresent}</div>
            <div class="stat-label">Present</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${totalAbsent}</div>
            <div class="stat-label">Absent</div>
        </div>
    `;
}

// Utility functions - UPDATED WITH BETTER DATE HANDLING
function formatDate(dateString) {
    if (!dateString) return 'No date';
    
    try {
        // Handle different date string formats
        let date;
        if (dateString.includes('T')) {
            date = new Date(dateString);
        } else {
            // For YYYY-MM-DD format
            date = new Date(dateString + 'T00:00:00');
        }
        
        // Check if date is valid
        if (isNaN(date.getTime())) {
            return 'Invalid Date';
        }
        
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return date.toLocaleDateString(undefined, options);
    } catch (error) {
        console.error('Error formatting date:', dateString, error);
        return 'Invalid Date';
    }
}

function formatTime(timeString) {
    if (!timeString) return 'No time';
    
    try {
        // Handle different time formats
        let timeParts;
        if (timeString.includes(':')) {
            timeParts = timeString.split(':');
        } else {
            // Assume it's already in HH:MM:SS format
            timeParts = [timeString.substring(0, 2), timeString.substring(2, 4)];
        }
        
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);
        
        if (isNaN(hours) || isNaN(minutes)) {
            return 'Invalid Time';
        }
        
        const period = hours >= 12 ? 'PM' : 'AM';
        const displayHours = hours % 12 || 12;
        const displayMinutes = minutes.toString().padStart(2, '0');
        
        return `${displayHours}:${displayMinutes} ${period}`;
    } catch (error) {
        console.error('Error formatting time:', timeString, error);
        return 'Invalid Time';
    }
}

function loadWeeklyCalendar() {
    updateWeeklyCalendar();
}